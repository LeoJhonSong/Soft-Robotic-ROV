# BUAA-ROV下位机

## 传感器刷新频率

`HARDWARE/TIMER/timer.c`:
```C
extern u32 lwip_localtime;	//lwip本地时间计数器,单位:ms
...
		lwip_localtime +=10; //加10
		Rate_time++;
		if(Rate_time>=50)//时基为1000ms
		{
			LED0=~LED0;//正常运行指示
			TCP_Send_Flg=0x05;//设置发送数据的标志
			Rate_time=0;//置0
		}
```

因此`TCP_Send_Flg=0x05;`应当是每500ms出现一次, 即**传感器数据刷新频率为0.5s**.

## 通讯方式

### 下位机内部： CAN

`HARDWARE/CAN/can.c`

理论上可以把传感器的数据读出来分析一波

### 下位机与上位机： tcp

`LWIP/lwip_app/tcp_client_demo/tcp_client_demo.c`

根据254行的注释, 应当可以做到断开连接3秒后自动重连上位机.
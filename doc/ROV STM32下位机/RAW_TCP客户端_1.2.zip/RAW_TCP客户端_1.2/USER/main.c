#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "data.h"
#include "led.h"

#include "lwip_comm.h"
#include "LAN8720.h"
#include "can.h"
#include "usmart.h"
#include "timer.h"

#include "sram.h"
#include "malloc.h"
#include "lwip/netif.h"
#include "lwip_comm.h"
#include "lwipopts.h"
#include "tcp_client_demo.h"
#include "iwdg.h"

//ALIENTEK 探索者STM32F407开发板
//RAW TCP Client实验
//技术支持：www.openedv.com
//广州市星翼电子科技有限公司
 

extern u8 tcp_client_flag;	 //TCP Client 测试全局状态标记变量
u8 i=0;//
u8 mbox;//发送邮箱
struct tcp_pcb *tcppcb;  	//定义一个TCP服务器控制块
struct ip_addr rmtipaddr;//定义一个远端IP地址
int main(void)
{

	delay_init(168);       	//延时初始化
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	//中断分组配置
	uart_init(115200);   	//串口波特率设置
	usmart_dev.init(84); 	//初始化USMART
	LED_Init();  			//LED初始化
	CAN1_Mode_Init();//初始化can总线	
	CAN_Tx_Commond_Init();//初始化CAN发送数据帧固定的部分
	CAN_Tx_PID_Init();//初始化CAN发送PID参数数据帧固定的部分
	TCP_Send_Buf_Init();//初始化TCP往上位机发送的信息
	mymem_init(SRAMIN);		//初始化内部内存池
	TIM3_Int_Init(999,839); 	//100khz的频率,计数1000为10ms
	while(lwip_comm_init()) 			//lwip初始化
	{
		LED1=0;
		delay_ms(500);
		LED0=0;
		delay_ms(500);
		LED1=1;
		delay_ms(500);
		LED0=1;
		delay_ms(500);
	}
	IWDG_Init(4,500);//独立看门狗初始化
#if LWIP_DHCP
	while((lwipdev.dhcpstatus!=2)&&(lwipdev.dhcpstatus!=0XFF))//等待DHCP获取成功/超时溢出
	{
		lwip_periodic_handle();
	}
#endif

	tcp_client_Start(tcppcb,rmtipaddr);  	//启动连接
	while(1)
	{
		IWDG_Feed();//喂狗	
/************************************************************/
		if(TCP_Receive_Flg==0xaa)//已经收到数据需要进行发送
		{
			//由于有三个发送邮箱，使用循环将可用空邮箱填满，提高使用效率，填满后可以跳出循环，执行其他代码，
			//主函数的循环执行一次后
			do
			{					
				mbox=CAN_Transmit(CAN1, CAN_Tx_Queues[i++]);  
				
			}while((mbox!=CAN_TxStatus_NoMailBox)&&CAN_Tx_Queues[i]!=NULL);
			/*跳出while循环有三种情况，没有空邮箱且还有数据没发送，则回减一
			没有空邮箱，但是已经发完数据了，此时还需要回减一，重新发送失败了的数据
			有空邮箱，但是已经发完数据了，这才是想要的结果直接清除数据标志*/
			/*如果没有空邮箱了,即表明有一组数据没有发送出去，直接回减1重新发送*/
			if(mbox==CAN_TxStatus_NoMailBox)//没有空邮箱，表明有一个数据组没发送成功，直接回减一
			{
				i--;//回减一
			}
			/*如果有空邮箱，但是已经发送完数据了，直接清0*/
			else if(CAN_Tx_Queues[i]==NULL)
			{
				TCP_Receive_Flg=0x00;//清除标志位
				i=0;//清除数组变量
			}
		}
/************************************************************************/
		if(PID_Receive_Flg==0xff)//如果收到需要PID数据包
		{
			if(CAN_PID_Send_Point!=NULL)
				mbox=CAN_Transmit(CAN1, CAN_PID_Send_Point);  //发送数据		
			if(mbox!=CAN_TxStatus_NoMailBox)//判断时候得到发送邮箱
				PID_Receive_Flg=0;//发送完成，则复位接受标志位，否则下次继续发送
		}
		/*下面为定时器的周期性处理函数，每500ms上传一次状态值*/
		/*CAN为半双工通信，需要尽可能的减少数据冲突的可能，以免丢包*/
		if(TCP_Send_Flg==0x05)//需要发送读取数据的命令进行读取数据
		{
			CAN1_Send_Remote(DR_Robot_Angle);//驱动板发命令，读取机器人姿态信息
			TCP_Send_Flg=0x0a;//设置标志位			
		}
		else if((TCP_Send_Flg==0x0a)&&((Can_Flg3&0xe0)==0xe0))//收到驱动板返回的姿态数据，
		{
			CAN1_Send_Remote(SEN1_Sensor_Back_ID);//给传感器1板发送命令，读取传感器的数据
			TCP_Send_Flg=0x50;//设置标志位	
			Can_Flg3&=~0xe0;//清除接收标志
		}
		else if((TCP_Send_Flg==0x50)&&((Can_Flg1&0x20)==0x20))//收到传感器2板发回来的数据
		{
			CAN1_Send_Remote(SEN2_Sensor_Back_ID);//给传感器2板发送命令，读取传感器数据
			TCP_Send_Flg=0xa0;//设置标志位
			Can_Flg1&=~0x20;//清除接收标志
		}
		else if((TCP_Send_Flg==0xa0)&&((Can_Flg2&0x20)==0x20))//收回传感器1板发回的数据
		{
			CAN1_Send_Remote(DR_ADC_Data1_ID);	//给驱动板发送数据读取ADC的数据
			TCP_Send_Flg=0xaa;//设置标志位		
			Can_Flg2&=~0x20;//清除接收标志
		}
		else if((TCP_Send_Flg==0xaa)&&((Can_Flg3&0x02)==0x02))
		{
			tcp_client_flag|=1<<7;//标记发送数据标志位;
			/*计算异或和校验,第二十7个数据是异或校验和*/
			TCP_Send_Buf[25]=XOR_Verify(TCP_Send_Buf,TCP_Send_Buf_Size-2);//减二的目的是去掉帧尾
			TCP_Send_Flg=0x00;//清除发送标志
			Can_Flg3&=~0x02;//清除接收标志
		}
/************************************************************************/
		tcp_client_Process(tcppcb,rmtipaddr);//运行TCP进程收发数据
	}
}










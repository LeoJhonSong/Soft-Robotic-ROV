1、本版更改了最大报文生存时间，
#define TCP_MSL 6000UL /* The maximum segment lifetime in milliseconds */
2、更改了：
#define TCP_FIN_WAIT_TIMEOUT 2000 /* milliseconds */
#define TCP_SYN_RCVD_TIMEOUT 2000 /* milliseconds */
3、更改了快速定时器的时基。
#define TCP_TMR_INTERVAL       100  /* The TCP timer interval in milliseconds. */
4、在（tcp_client_Process）函数中添加了连接关闭的判断
	 if(tcppcb->state==CLOSED)//如果已经关闭了连接，则删除TCP
	 {
		tcp_client_flag&=~(1<<5);//标记连接断开了
	 }
5、添加了独立看门狗

8-13日，
更改了PID调控协议

8-17日早1点

修改了PID传送CAN实现方式，有发送队列改为发送指针
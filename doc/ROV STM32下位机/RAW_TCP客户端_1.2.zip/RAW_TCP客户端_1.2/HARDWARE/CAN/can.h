#ifndef __CAN_H
#define __CAN_H	 
#include "sys.h"	    
//////////////////////////////////////////////////////////////////////////////////	 
//本程序只供学习使用，未经作者许可，不得用于其它任何用途
//ALIENTEK STM32F407开发板
//CAN驱动 代码	   
//正点原子@ALIENTEK
//技术论坛:www.openedv.com
//创建日期:2014/5/7
//版本：V1.0 
//版权所有，盗版必究。
//Copyright(C) 广州市星翼电子科技有限公司 2014-2024
//All rights reserved									  
////////////////////////////////////////////////////////////////////////////////// 	 

extern u16 Can_Flg1;//用于接收来自传感器板子1的数据
extern u16 Can_Flg2;//用于接收来自传感器板子2的数据
extern u16 Can_Flg3;//用于接收驱动板的数据
/****************************************************************************/
/*传感器采集板1的canID定义*/
#define SEN1_Water_Waring_ID 0x01//漏水报警信号，优先级比较高，一位数据
#define SEN1_Tem_Waring_ID 0x02//发送高温报警信号，优先级比较高，一位数据
#define SEN1_FIFO0_OV_ID 0x03//发送接收邮箱0数据溢出信号
/**********************************************/
#define SEN1_LED_PWM_ID 0x21//用于设定灯的亮度

#define SEN1_Sensor_Back_ID 0x22//用于发送漏水信号和传感器信息


#define SEN1_Water_Flag_ID 0x23//用于接收是否漏水信号
#define SEN1_Temperature_ID 0x24//用于返回温度值
#define SEN1_Servo1_Position_ID 0x26//用于设定备用舵机位置
#define SEN1_Servo2_Position_ID 0x27//用与设定备用舵机位置
/*************************************************************************/
/*传感器采集板2的canID定义*/
#define SEN2_Water_Waring_ID 0x04//用于发送漏水报警信号，优先级比较高，一位数据
#define SEN2_Tem_Waring_ID 0x05//用于发送高温报警信号，优先级比较高，一位数据
#define SEN2_FIFO0_OV_ID 0x06//用于发送接收邮箱0数据溢出信号
/**********************************************/
#define SEN2_LED_PWM_ID 0x31//用于设定灯的亮度

#define SEN2_Sensor_Back_ID 0x32//用于发送漏水信号和传感器信息

#define SEN2_Water_Flag_ID 0x33//用于发送是否漏水信号
#define SEN2_Temperature_ID 0x34//用于返回温度值
#define SEN2_Servo1_Position_ID 0x36//用于设定备用舵机位置
#define SEN2_Servo2_Position_ID 0x37//用与设定备用舵机位置
/**********************************************************************/
/*电机驱动板的canID*/
#define DR_Motor_Speed_ID 0x11//用于设定电机速度

//#define DR_Motor_Driection_ID 0x12//用于设定机器人的方向
//#define DR_Motor_Deep_ID 0x14//用于设定机器人的方向

#define DR_Control_Model_ID 0x15//用于设定机器人的控制模式

#define DR_ADC_Data1_ID 0x13//用于返回ADC值

#define DR_Servo1_Position_ID 0x16//用于设定备用舵机位置
#define DR_Servo2_Position_ID 0x17//用与设定备用舵机位置

#define DR_Robot_Pitch_ID 0x18//用于返回Pitch角
#define DR_Robot_Roll_ID 0x19//用于返回Roll角
#define DR_Robot_Yaw_ID 0x1a//用于返回Yaw角
#define DR_Robot_Angle 0x1b//用于返回三个角，即上面三个角相连返回				    
/**********************************************/	
#define DR_FIFO0_OV_ID 0x07//用于返回FIFO溢出警告
/*********************************************************************/	
/*********************************/

#define DR_DEEP_PID_ID 0x51
#define DR_FB_PID_ID 0x52
#define DR_SW_PID_ID 0x53
#define DR_WRITE_FLASH_ID 0x54
#define DR_STATIC_PID_ID 0x55
/*******************************/
//CAN1接收RX0中断使能
#define CAN1_RX0_INT_ENABLE	1		//0,不使能;1,使能.								    
										 							 				    
u8 CAN1_Mode_Init(void);//CAN初始化
 
u8 CAN1_Send_Msg(u8* msg,u8 len);						//发送数据
u8 CAN1_Send_Remote(u32 StdId);

u8 CAN1_FIFO0_Receive_Msg(void);
u8 CAN1_FIFO1_Receive_Msg(void);



#endif


















#include "can.h"
#include "led.h"
#include "delay.h"
#include "usart.h"
#include "data.h"


//////////////////////////////////////////////////////////////////////////////////	 
//本程序只供学习使用，未经作者许可，不得用于其它任何用途
//ALIENTEK STM32F407开发板
//CAN驱动 代码	   
//正点原子@ALIENTEK
//技术论坛:www.openedv.com
//创建日期:2014/5/7
//版本：V1.0 
//版权所有，盗版必究。
//Copyright(C) 广州市星翼电子科技有限公司 2014-2024
//All rights reserved									  
////////////////////////////////////////////////////////////////////////////////// 	 

u16 Can_Flg1;//用于接收来自传感器板子1的数据
/*******************************************************************************

*bit0 0x01 置1 表示需要发送数据帧0x21,设置LEDPWM数值
*bit1 0x02 置1 表示需要发送远程帧0x23,返回是否漏水
*bit2 0x04 置1 表示需要发送远程帧0x24,返回舱内温度值
*bit3 0x08 置1 表示需要发送Servo1位置信息0x26
*bit4 0x10 置1 表示需要发送Servo2位置信息0x27
*bit5	0x20 置1 表示收到漏水信息和温度值
*bit6
*bit7
*bit8 0x0100 置1 表示漏水
*bit9 0x0200 置1 表示高温报警
*bit10 0x0400 置1 表示接收邮箱数据溢出
****设置标志位的目的是防止帧丢失，即当前主控的请求还未处理完，又来了下一个请求****
****这样设置会使最新的请求或命令始终覆盖旧的请求或命令*****
*************************************************************************************/
u16 Can_Flg2;//用于接收来自传感器板子2的数据
/*******************************************************************************

*bit0 0x01 置1 表示需要发送数据帧0x31,设置LEDPWM数值
*bit1 0x02 置1 表示需要发送远程帧0x33,返回是否漏水
*bit2 0x04 置1 表示需要发送远程帧0x34,返回舱内温度值
*bit3 0x08 置1 表示需要发送Servo1位置信息0x36
*bit4 0x10 置1 表示需要发送Servo2位置信息0x37
*bit5	0x20 置1 表示收到漏水信息和温度值
*bit6
*bit7
*bit8 0x0100 置1 表示漏水
*bit9 0x0200 置1 表示高温报警
*bit10 0x0400 置1 表示接收邮箱数据溢出
****设置标志位的目的是防止帧丢失，即当前主控的请求还未处理完，又来了下一个请求****
****这样设置会使最新的请求或命令始终覆盖旧的请求或命令*****
*************************************************************************************/
u16 Can_Flg3;//用于接收驱动板的数据
/************************************************************************************
*bit0 0x01 置1 表示需要发送数据帧0x11,电机速度设定值
*bit1 0x02 置1 表示需要发送远程帧0x13,需要返回ADC1数值
*bit2 0x04 置1 表示需要发送远程帧0x14,需要返回ADC2数值
*bit3 0x08 置1 表示需要发送数据帧0X16,Servo1位置信息
*bit4 0x10 置1 表示需要发送数据帧0x17,Servo2位置信息
*bit5 0x20 置1 表示需要发送远程帧0x18,返回Pitch角
*bit6 0x40 置1 表示需要发送远程帧0x19,返回Roll角
*bit7 0x80 置1 表示需要发送远程帧0x1a,返回Yaw角
*bit8 0x0100 置1 表示需要发送远程帧0x1b,返回三个连续的角
*bit9 0x0200 置1 表示需要发送数据帧0x12,设定机器人前进方向
*bit10 0x0400 置1 表示收到FIFO溢出信号
***************************************************************************************/
//CAN初始化
//tsjw:重新同步跳跃时间单元.范围:CAN_SJW_1tq~ CAN_SJW_4tq
//tbs2:时间段2的时间单元.   范围:CAN_BS2_1tq~CAN_BS2_8tq;
//tbs1:时间段1的时间单元.   范围:CAN_BS1_1tq ~CAN_BS1_16tq
//brp :波特率分频器.范围:1~1024; tq=(brp)*tpclk1
//波特率=Fpclk1/((tbs1+1+tbs2+1+1)*brp);
//mode:CAN_Mode_Normal,普通模式;CAN_Mode_LoopBack,回环模式;
//Fpclk1的时钟在初始化的时候设置为42M,如果设置CAN1_Mode_Init(CAN_SJW_1tq,CAN_BS2_6tq,CAN_BS1_7tq,6,CAN_Mode_LoopBack);
//则波特率为:42M/((6+7+1)*3)=1000Kbps
//返回值:0,初始化OK;
//    其他,初始化失败; 


u8 CAN1_Mode_Init(void)
{

  	GPIO_InitTypeDef GPIO_InitStructure; 
	  CAN_InitTypeDef        CAN_InitStructure;
  	CAN_FilterInitTypeDef  CAN_FilterInitStructure;
#if CAN1_RX0_INT_ENABLE 
   	NVIC_InitTypeDef  NVIC_InitStructure;
#endif
    //使能相关时钟
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);//使能PORTA时钟	                   											 

  	RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);//使能CAN1时钟	
	
    //初始化GPIO
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11| GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;//复用功能
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//推挽输出
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//上拉
    GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化PA11,PA12
	
	  //引脚复用映射配置
	  GPIO_PinAFConfig(GPIOA,GPIO_PinSource11,GPIO_AF_CAN1); //GPIOA11复用为CAN1
	  GPIO_PinAFConfig(GPIOA,GPIO_PinSource12,GPIO_AF_CAN1); //GPIOA12复用为CAN1
	  
  	//CAN单元设置
   	CAN_InitStructure.CAN_TTCM=DISABLE;	//非时间触发通信模式   
  	CAN_InitStructure.CAN_ABOM=DISABLE;	//软件自动离线管理	  
  	CAN_InitStructure.CAN_AWUM=DISABLE;//睡眠模式通过软件唤醒(清除CAN->MCR的SLEEP位)
  	CAN_InitStructure.CAN_NART=DISABLE;	//允许报文自动传送 
  	CAN_InitStructure.CAN_RFLM=DISABLE;	//报文不锁定,新的覆盖旧的  
  	CAN_InitStructure.CAN_TXFP=DISABLE;	//优先级由报文标识符决定 
  	CAN_InitStructure.CAN_Mode= CAN_Mode_Normal;	 //模式设置 
  	CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;	//重新同步跳跃宽度(Tsjw)为tsjw+1个时间单位 CAN_SJW_1tq~CAN_SJW_4tq
  	CAN_InitStructure.CAN_BS1=CAN_BS1_6tq; //Tbs1范围CAN_BS1_1tq ~CAN_BS1_16tq
  	CAN_InitStructure.CAN_BS2=CAN_BS2_7tq;//Tbs2范围CAN_BS2_1tq ~	CAN_BS2_8tq
  	CAN_InitStructure.CAN_Prescaler=3;  //分频系数(Fdiv)为brp+1	
  	CAN_Init(CAN1, &CAN_InitStructure);   // 初始化CAN1 
/*采用标识符过滤器，筛选出0x020~0x02f范围内的信息*/
/*CAN_F0R1[15:8] CAN_F0R1[7:0]*//*低16位为ID号*/
/* 0000  0100     0000  0000*/
/*STID[10:3]     STID[2:0] RTR IDE EXID[17:15]*/
/*CAN_F0R1[31:24] CAN_F0R1[23:16]*//*高16位为屏蔽位*/
/* 1111  1110     0000  1000*/
/*0X0400*/
/*采用标识符过滤器，筛选出0x030~0x03f范围内的信息*/
/*CAN_F0R1[15:8] CAN_F0R1[7:0]*//*低16位为ID号*/
/* 0000  0110     0000  0000*/
/*STID[10:3]     STID[2:0] RTR IDE EXID[17:15]*/
/*CAN_F0R1[31:24] CAN_F0R1[23:16]*//*高16位为屏蔽位*/
/* 1111  1110     0000  1000*/
/*0X0600*/    
		//配置过滤器
 	  CAN_FilterInitStructure.CAN_FilterNumber=0;	  //过滤器0
  	CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask; 
  	CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_16bit; //16位 
  	CAN_FilterInitStructure.CAN_FilterIdHigh=0x0600;//F0R1高16位,做屏蔽位
  	CAN_FilterInitStructure.CAN_FilterIdLow=0x0400;//F0R1低16位，做为ID
  	CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0xfe08;//F0R2高16位,做屏蔽位
  	CAN_FilterInitStructure.CAN_FilterMaskIdLow=0xfe08;//F0R2低16位，做为ID
   	CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_Filter_FIFO0;//过滤器0关联到FIFO0
  	CAN_FilterInitStructure.CAN_FilterActivation=ENABLE; //激活过滤器0
  	CAN_FilterInit(&CAN_FilterInitStructure);//滤波器初始化
/*
*设置过滤器组2，过滤出0x42,这事深度传感器的数据，以10HZ的频率上传
*CAN_F0R1[15:8] CAN_F0R1[7:0]低16位为ID号
*0000  1000     0100  0000
*STID[10:3]     STID[2:0] RTR IDE EXID[17:15]
*0x0840
**/
 	  CAN_FilterInitStructure.CAN_FilterNumber=2;	  //过滤器2
  	CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdList; 
  	CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_16bit; //16位 
  	CAN_FilterInitStructure.CAN_FilterIdHigh=0x0840;//F0R1高16位,做为ID
  	CAN_FilterInitStructure.CAN_FilterIdLow=0x0840;//F0R1低16位，做为ID
  	CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0x0840;//F0R2高16位,做为ID
  	CAN_FilterInitStructure.CAN_FilterMaskIdLow=0x0840;//F0R2低16位，做为ID
   	CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_Filter_FIFO0;//过滤器2关联到FIFO0
  	CAN_FilterInitStructure.CAN_FilterActivation=ENABLE; //激活过滤器2
  	CAN_FilterInit(&CAN_FilterInitStructure);//滤波器初始化
		
/*采用标识符过滤器，筛选出0x010~0x01f范围内的信息*/
/*CAN_F0R1[15:8] CAN_F0R1[7:0]*//*低16位为ID号*/
/* 0000  0010     0000  0000*/
/*STID[10:3]     STID[2:0] RTR IDE EXID[17:15]*/
/*CAN_F0R1[31:24] CAN_F0R1[23:16]*//*高16位为屏蔽位*/
/* 1111  1110     0000  1000*/
/*0X0100*/
/*采用标识符过滤器，筛选出0x000~0x00f范围内的信息*/
/*CAN_F0R1[15:8] CAN_F0R1[7:0]*//*低16位为ID号*/
/* 0000  0000     0000  0000*/
/*STID[10:3]     STID[2:0] RTR IDE EXID[17:15]*/
/*CAN_F0R1[31:24] CAN_F0R1[23:16]*//*高16位为屏蔽位*/
/* 1111  1110     0000  1000*/
/*0X0000*/    
		//配置过滤器
 	  CAN_FilterInitStructure.CAN_FilterNumber=1;	  //过滤器1
  	CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask; 
  	CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_16bit; //16位 
  	CAN_FilterInitStructure.CAN_FilterIdHigh=0x0000;//F0R1高16位,做屏蔽位
  	CAN_FilterInitStructure.CAN_FilterIdLow=0x0200;//F0R1低16位，做为ID
  	CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0xfe08;//F0R2高16位,做屏蔽位
  	CAN_FilterInitStructure.CAN_FilterMaskIdLow=0xfe08;//F0R2低16位，做为ID
   	CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_Filter_FIFO1;//过滤器1关联到FIFO1
  	CAN_FilterInitStructure.CAN_FilterActivation=ENABLE; //激活过滤器1
  	CAN_FilterInit(&CAN_FilterInitStructure);//滤波器初始化
		
#if CAN1_RX0_INT_ENABLE
	
	  CAN_ITConfig(CAN1,CAN_IT_FMP0,ENABLE);//FIFO0消息挂号中断允许.		    
  
  	NVIC_InitStructure.NVIC_IRQChannel = CAN1_RX0_IRQn;
  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;     // 主优先级为1
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;            // 次优先级为0
  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  	NVIC_Init(&NVIC_InitStructure);
		
		CAN_ITConfig(CAN1,CAN_IT_FMP1,ENABLE);//FIFO0消息挂号中断允许.
		
  	NVIC_InitStructure.NVIC_IRQChannel = CAN1_RX1_IRQn;
  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;     // 主优先级为1
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;            // 次优先级为0
  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  	NVIC_Init(&NVIC_InitStructure);
		
#endif
	return 0;
}   
 
#if CAN1_RX0_INT_ENABLE	//使能RX0中断
//中断服务函数			    
void CAN1_RX0_IRQHandler(void)
{
//	LED1=~LED1;
CAN1_FIFO0_Receive_Msg();
}
#endif

void CAN1_RX1_IRQHandler(void)
{

//LED1=~LED1;
	CAN1_FIFO1_Receive_Msg();
}

//can发送一组数据(固定格式:ID为0X12,标准帧,数据帧)	
//len:数据长度(最大为8)				     
//msg:数据指针,最大为8个字节.
//返回值:0,成功;
//		 其他,失败;
u8 CAN1_Send_Msg(u8* msg,u8 len)
{	
  u8 mbox;
  u16 i=0;
  CanTxMsg TxMessage;
  TxMessage.StdId=0x12;	 // 标准标识符为0
  TxMessage.ExtId=0x12;	 // 设置扩展标示符（29位）
  TxMessage.IDE=0;		  // 使用扩展标识符
  TxMessage.RTR=0;		  // 消息类型为数据帧，一帧8位
  TxMessage.DLC=len;							 // 发送两帧信息
  for(i=0;i<len;i++)
  TxMessage.Data[i]=msg[i];				 // 第一帧信息          
  mbox= CAN_Transmit(CAN1, &TxMessage);   
  i=0;
  while((CAN_TransmitStatus(CAN1, mbox)==CAN_TxStatus_Failed)&&(i<0XFFF))i++;	//等待发送结束
  if(i>=0XFFF)return 1;
  return 0;		

}
/****
*
*发送远程帧（遥控帧）用于获取想要读的数据
*
*传入远程帧的ID
*
*/
u8 CAN1_Send_Remote(u32 StdId)
{
	u8 mbox;
	u16 i=0;

	CanTxMsg TxMessage;
	TxMessage.StdId=StdId;			// 标准标识符 
//	TxMessage.ExtId=0x12;			// 设置扩展标示符 
	TxMessage.IDE=CAN_Id_Standard; 	// 标准帧
	TxMessage.RTR=CAN_RTR_Remote;		// 远程帧
	
	mbox= CAN_Transmit(CAN1, &TxMessage);  
	while(mbox==CAN_TxStatus_NoMailBox)	//死循环保证数据能发出去不会遇到空邮箱
		mbox= CAN_Transmit(CAN1, &TxMessage);  
	

	while((CAN_TransmitStatus(CAN1, mbox)==CAN_TxStatus_Failed)&&(i<0XFFF))i++;	//等待发送结束
	if(i>=0XFFF)return 1;
	return 0;	 	
}

//can口接收数据查询
//返回值:0,无数据被收到;
//		 其他,接收的数据长度;
u8 CAN1_FIFO0_Receive_Msg(void)
{		
 	u8 i;
	CanRxMsg RxMessage;
	u8 Return_Data_LEN=0;
	u32 Can_StdId;
	if( CAN_MessagePending(CAN1,CAN_FIFO0)==0)return 0;		//没有接收到数据,直接退出 
	CAN_Receive(CAN1, CAN_FIFO0, &RxMessage);//读取数据	
	Can_StdId=RxMessage.StdId;//获取数据的ID号

	if(RxMessage.RTR==CAN_RTR_Remote)//如果接收到的是远程帧
	{
//主控板不能收到远程帧
		Return_Data_LEN=0;
	}
	/*如果接收到的数据帧，需要将数据及时copy出来*/
	/*由于采用的是循环等待的发送方式，所以在主函数里进行发送数据，通过全局变量标志位进行通知*/
	if(RxMessage.RTR==CAN_RTR_Data)
	{
		if((Can_StdId&0x00f0)==0x0020)//数据来自采集板1
		{
			switch(Can_StdId)
			{
				case 0x22://表示收到0x22,含有sensor1的数据，前两个字节表示温度，后一个字节表示是否漏水，漏水则为0xaa
					for(i=0;i<3;i++)
						TCP_Send_Buf[i+2]=RxMessage.Data[i];//将数据传入sensor1的前三位
										/*bit2-bit3-bit4*/
					Can_Flg1|=0x20;//设置标志位，在主函数中进行处理				
				break;
/*****************************************************************************/	
/*暂时不用下面的功能*/				
				case 0x23: //表示收到数据帧0x23,含有是否漏水信息
					if(RxMessage.Data[0]==0xcc)
						SEN1_Water_Waring=1;//已经漏水啦
					else
						SEN1_Water_Waring=0;//还没有漏水					
					Can_Flg1|=0x02;//设置标志位，在主函数中进行处理
				break;
				case 0x24: //表示收到数据帧0x24,含有温度值
	////协议未定
					Can_Flg1|=0x04;//设置标志位，在主函数中进行处理
				break;
/******************************************************************************/
			} 
		}		
		else if((Can_StdId&0x00f0)==0x0030)//数据来自采集板2
		{
			switch(Can_StdId)
			{
				case 0x32:
					for(i=0;i<3;i++)//表示收到0x32,含有sensor2的数据，前两个字节表示温度，后一个字节表示是否漏水，漏水则为0xaa
						TCP_Send_Buf[i+5]=RxMessage.Data[i];//传入sensor2的数据，bit5-bit7
										/*bit5-bit6-bit7*/
					Can_Flg2|=0x20;//设置标志位，在主函数中进行处理									
				break;
/*************************************************************************/
/*暂时未用以下功能*/				
				case 0x33: //表示收到数据帧0x23,含有是否漏水信息
					if(RxMessage.Data[0]==0xcc)
						SEN1_Water_Waring=1;//已经漏水啦
					else
						SEN1_Water_Waring=0;//还没有漏水					
					Can_Flg2|=0x02;//设置标志位，在主函数中进行处理
				break;
				case 0x34: //表示收到数据帧0x24,含有温度值
	////协议未定
					Can_Flg2|=0x04;//设置标志位，在主函数中进行处理
				break;
/***********************************************************************/
			} 
		}	
		else if(Can_StdId==0x42) //收到的是深度传感器的值
		{			
			for(i=0;i<2;i++)
				TCP_Send_Buf[i+8]=RxMessage.Data[i];//传入数据,深度传感器放在dit8-dit9
		}
		Return_Data_LEN=RxMessage.DLC;//返回数据长度
	}
	return Return_Data_LEN;	
}
/*
*
*can_FIFO1接收函数
*返回接收到数据的长度
*
*
*/
u8 CAN1_FIFO1_Receive_Msg(void)
{		
 	u8 i;
	CanRxMsg RxMessage;
	u8 Return_Data_LEN=0;
	u32 Can_StdId;
	if( CAN_MessagePending(CAN1,CAN_FIFO1)==0)return 0;		//没有接收到数据,直接退出 
	CAN_Receive(CAN1, CAN_FIFO1, &RxMessage);//读取数据	
	Can_StdId=RxMessage.StdId;//获取数据的ID号

	if(RxMessage.RTR==CAN_RTR_Remote)//如果接收到的是远程帧
	{
//主控板不能收到远程帧
		Return_Data_LEN=0;
	}
	/*如果接收到的数据帧，需要将数据及时copy出来*/
	/*由于采用的是循环等待的发送方式，所以在主函数里进行发送数据，通过全局变量标志位进行通知*/
	if(RxMessage.RTR==CAN_RTR_Data)
	{
		if((Can_StdId&0x00f0)==0x0010)//数据来自驱动板
		{
			switch(Can_StdId)
			{
				case 0x13: //表示收到数据帧0x13,返回的ADC的值
					for(i=0;i<6;i++)
						TCP_Send_Buf[i+10]=RxMessage.Data[i];//传入ADC的数据，
				/*bit10-bit11-bit12-bit13-bit14-bit15*/				
				Can_Flg3|=0x02;//设置标志位，在主函数中进行处理
				break;
				case 0x18: //表示收到数据帧0x18,获得Pitch角，压缩BCD码
					for(i=0;i<3;i++)
					TCP_Send_Buf[i+16]=RxMessage.Data[i];//转存读取的数据
				/*bit18-bit19-bit20*/
					Can_Flg3|=0x20;//设置标志位，在主函数中进行处理
				break;
				case 0x19: //表示收到数据帧0x19,获得Roll角，压缩BCD码
					for(i=0;i<3;i++)
					TCP_Send_Buf[i+19]=RxMessage.Data[i];//转存读取的数据
				/*bit19-bit-20-bit21*/
					Can_Flg3|=0x40;//设置标志位，在主函数中进行处理
				break;
				case 0x1a: //表示收到数据帧0x1a,获得Yaw角，压缩BCD码
					for(i=0;i<3;i++)
					TCP_Send_Buf[i+22]=RxMessage.Data[i];//转存读取的数据
				/*bit22-bit23-bit24*/
					Can_Flg3|=0x80;//设置标志位，在主函数中进行处理
				break;
			} 
		}	
/******************************************************************************/
		/*报警功能没用*/
		else//都不是则说明收到了报警信号
		{
			switch(Can_StdId)
			{
				case 0x01: //表示收到数据帧0x01，漏水报警
					if(RxMessage.Data[0]==0xcc)
						SEN1_Water_Waring=1;//已经漏水啦
					else
						SEN1_Water_Waring=0;//还没有漏水					
					Can_Flg1|=0x0100;//设置标志位，在主函数中进行处理
				break;
				case 0x02: //表示收到数据帧0x02,高温报警
	////协议未定
					Can_Flg1|=0x0200;//设置标志位，在主函数中进行处理
				break;
				case 0x03: //表示收到数据帧0x03,接收邮箱数据溢出
	////协议未定
					Can_Flg1|=0x0400;//设置标志位，在主函数中进行处理
				break;
				case 0x04: //表示收到数据帧0x04，漏水报警
					if(RxMessage.Data[0]==0xcc)
						SEN2_Water_Waring=1;//已经漏水啦
					else
						SEN2_Water_Waring=0;//还没有漏水					
					Can_Flg2|=0x0100;//设置标志位，在主函数中进行处理
				break;
				case 0x05: //表示收到数据帧0x05,高温报警
	////协议未定
					Can_Flg2|=0x0200;//设置标志位，在主函数中进行处理
				break;
				case 0x06: //表示收到数据帧0x06,接收邮箱数据溢出
	////协议未定
					Can_Flg2|=0x0400;//设置标志位，在主函数中进行处理
				break;
				case 0x07: //表示收到数据帧0x07,接收邮箱数据溢出
	////协议未定
					Can_Flg3|=0x0400;//设置标志位，在主函数中进行处理
				break;
			}
/*****************************************************************/			
		}
		Return_Data_LEN=RxMessage.DLC;//返回数据长度
	}
	return Return_Data_LEN;	
}











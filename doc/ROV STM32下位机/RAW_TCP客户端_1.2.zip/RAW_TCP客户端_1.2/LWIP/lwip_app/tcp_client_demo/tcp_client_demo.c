#include "tcp_client_demo.h" 
#include "delay.h"
#include "usart.h"
#include "led.h"


#include "malloc.h"
#include "stdio.h"
#include "string.h" 
#include "data.h"


//////////////////////////////////////////////////////////////////////////////////	 
//本程序只供学习使用，未经作者许可，不得用于其它任何用途
//ALIENTEK STM32F407开发板
//TCP Client 测试代码	   
//正点原子@ALIENTEK
//技术论坛:www.openedv.com
//创建日期:2014/8/15
//版本：V1.0
//版权所有，盗版必究。
//Copyright(C) 广州市星翼电子科技有限公司 2009-2019
//All rights reserved									  
//*******************************************************************************
//修改信息
//无
////////////////////////////////////////////////////////////////////////////////// 	   

/**********
*
*
*修改，
*2017-07-29-zx
*/

 
//TCP Client接收数据缓冲区
u8 tcp_client_recvbuf[TCP_CLIENT_RX_BUFSIZE];	
//TCP服务器发送数据内容
//const char *Lower_F4_sendbuf="Explorer STM32F407 TCP Client send data\r\n";

//TCP Client 测试全局状态标记变量
//bit7:0,没有数据要发送;1,有数据要发送
//bit6:0,没有收到数据;1,收到数据了.
//bit5:0,没有连接上服务器;1,连接上服务器了.
//bit4~0:保留
u8 tcp_client_flag;	 


//TCP Client 启动连接
void tcp_client_Start(struct tcp_pcb *tcppcb,struct ip_addr rmtipaddr)
{

	tcppcb=tcp_new();	//创建一个新的pcb
	if(tcppcb)			//创建成功
	{
		IP4_ADDR(&rmtipaddr,lwipdev.remoteip[0],lwipdev.remoteip[1],lwipdev.remoteip[2],lwipdev.remoteip[3]); 
		tcp_connect(tcppcb,&rmtipaddr,TCP_CLIENT_PORT,tcp_client_connected);  //连接到目的地址的指定端口上,当连接成功后回调tcp_client_connected()函数
 	}
	
	while((tcp_client_flag&1<<5)==0)//未连接上,等待连接
	{
		lwip_periodic_handle();//周期性调用函数

		if(Connect_Count>=800)//超过8秒,跳出
		{ 
			Connect_Count=0;
			break;
		}

	}
	if(tcp_client_flag&1<<5)
		LED1=0;//灯亮显示连接正常
} 
//接收数据处理及周期性函数调用进行发送数据以及重连判断及连接状态指示
void tcp_client_Process(struct tcp_pcb *tcppcb,struct ip_addr rmtipaddr)
{
	u16 temp;//用来存储信息字的数据
//	u8 XOR_temp;//奇偶校验变量
	u8 i,j=0;//分别是拷贝数据时的变量和加入缓冲队列时的变量
	lwip_periodic_handle();//周期性调用函数

	 if(tcppcb->state==CLOSED)//如果已经关闭了连接，则删除TCP
	 {
		tcp_client_flag&=~(1<<5);//标记连接断开了
	 }
	
	if(tcp_client_flag&1<<6)//是否收到数据?
	{
//		LED1=~LED1;
		//数据处理

		if((tcp_client_recvbuf[0]==0xFE)&&(tcp_client_recvbuf[1]==0xFE))//正确的帧头及校验和
		{
//			XOR_temp=XOR_Verify(tcp_client_recvbuf,TCP_Receive_Buf_Size-2);
		//if(tcp_client_recvbuf[24]==XOR_temp)
			//{
			
			temp=(tcp_client_recvbuf[2]<<8)+tcp_client_recvbuf[3];//读取信息字
			CAN_Tx_Queues_Reset(); //重置发送队列指针为NULL
			j=0;//这里一定要置0以正确配置发送缓冲队列
/*************************************************************************************/
			if(temp&0x0001)//第一个数据帧为sensor1的LED_PWM数据
			{
				for(i=0;i<2;i++)//约定好，LED_PWM有2个字节，存放在数组0位
				CAN_Tx_Commond[0].Data[i]= tcp_client_recvbuf[4+i];
				CAN_Tx_Queues[j++]=&(CAN_Tx_Commond[0]);//将数组0的指针加入队列
			}
			if(temp&0x0002)//第二个数据帧为sensor2的LED_PWM数据
			{
				for(i=0;i<2;i++)//约定好，LED_PWM有2个字节，存放在数组1位
				CAN_Tx_Commond[1].Data[i]= tcp_client_recvbuf[6+i];
				CAN_Tx_Queues[j++]=&(CAN_Tx_Commond[1]);//将数组1的指针加入队列				
			}
/******************************************************************************/
			/*舵机信息*/				
			if(temp&0x0004)//第三个数据帧为sensor1的servo1数据
			{
				for(i=0;i<2;i++)//约定好，servo1有2个字节，存放在数组2位
				CAN_Tx_Commond[2].Data[i]= tcp_client_recvbuf[8+i];	
				CAN_Tx_Queues[j++]=&(CAN_Tx_Commond[2]);//将数组2的指针加入队列				
			}
			if(temp&0x0008)//第四个数据帧为sensor2的servo1数据
			{
				for(i=0;i<2;i++)//约定好，servo1有2个字节，存放在数组3位
				CAN_Tx_Commond[3].Data[i]= tcp_client_recvbuf[10+i];
				CAN_Tx_Queues[j++]=&(CAN_Tx_Commond[3]);//将数组3的指针加入队列				
			}
/*************************************************************************************/
			/*以下为预留信息*/				
			if(temp&0x0010)//第五个数据帧为sensor1的servo2数据
			{
				for(i=0;i<2;i++)//约定好，servo2有2个字节，存放在数组4位
				CAN_Tx_Commond[4].Data[i]= tcp_client_recvbuf[12+i];
				CAN_Tx_Queues[j++]=&(CAN_Tx_Commond[4]);//将数组4的指针加入队列				
			}
			if(temp&0x0020)//第六个数据帧为sensor2的servo2数据
			{
				for(i=0;i<2;i++)//约定好，servo2有2个字节，存放在数组5位
				CAN_Tx_Commond[5].Data[i]= tcp_client_recvbuf[14+i];
				CAN_Tx_Queues[j++]=&(CAN_Tx_Commond[5]);//将数组5的指针加入队列				
			}
			if(temp&0x0040)//第7个数据帧为driver的servo1数据
			{
				for(i=0;i<2;i++)//约定好，servo1有2个字节，存放在数组6位
				CAN_Tx_Commond[6].Data[i]= tcp_client_recvbuf[16+i];
				CAN_Tx_Queues[j++]=&(CAN_Tx_Commond[6]);//将数组6的指针加入队列				
			}
			if(temp&0x0080)//第8个数据帧为driver的servo2数据
			{
				for(i=0;i<2;i++)//约定好，servo2有2个字节，存放在数组7位
				CAN_Tx_Commond[7].Data[i]= tcp_client_recvbuf[18+i];
				CAN_Tx_Queues[j++]=&(CAN_Tx_Commond[7]);//将数组7的指针加入队列				
			}
/*************************************************************************************/
			/*以下解析摇杆数据*/	
/*信息字的第8位是遥控还是测试，如果为1就是遥控，如果为0就是测试*/
/*向下发的是遥控帧*/			
			if((temp&0x0100)==0x0100)//第9个数据帧为driver的运动参数
			{
				for(i=0;i<4;i++)//约定好，姿态有4个字节，存放在数组8位
				CAN_Tx_Commond[8].Data[i]= tcp_client_recvbuf[20+i];
				CAN_Tx_Commond[8].Data[4]=0xaa;//在第5个数据进行标记为遥控帧
				if((temp&0x0200)==0x0200)//在遥控帧里面判断是否闭环,1表示闭环，0表示开环
					CAN_Tx_Commond[8].Data[5]=0xaa;//如果闭环，就在第6个数据里发0xaa,做标记。
				else 
					CAN_Tx_Commond[8].Data[5]=0x55;//如果开环，就在第6个数据里发0x55,做标记。					
				CAN_Tx_Queues[j++]=&(CAN_Tx_Commond[8]);//将数组8的指针加入队列				
			}
			else//如果信息字的第8位为0则进行测试
			{
				for(i=0;i<4;i++)//约定好，姿态有4个字节，存放在数组8位
				CAN_Tx_Commond[8].Data[i]= tcp_client_recvbuf[20+i];
				CAN_Tx_Commond[8].Data[4]=0x55;//在第5个数据进行标记为测试帧
				
				CAN_Tx_Commond[8].Data[5]=0x00;//就在第6个数据里发0x00,不做标记测试部分开环闭环。					
				CAN_Tx_Queues[j++]=&(CAN_Tx_Commond[8]);//将数组8的指针加入队列			
				
			}
/*************************************************************************************/			
			TCP_Receive_Flg=0xaa;//标记已经收到数据并处理好了
	//	}//奇偶校验
		}
		else if((tcp_client_recvbuf[0]==0xFB)&&(tcp_client_recvbuf[1]==0xFB))//这是PID调节的帧头
		{
//			XOR_temp=XOR_Verify(tcp_client_recvbuf,TCP_Receive_Buf_Size-2);
			
//		if(tcp_client_recvbuf[24]==XOR_temp)
//		{
			temp=tcp_client_recvbuf[2];//读取信息字
			CAN_PID_Send_Point=NULL;//给指针复位
		/*实际上每次只能传递一组PID数据,这里采用发送指针*/
/********************************************************************************/
			if(temp==0x01)//收到了深度PID参数   
			{
				for(i=0;i<7;i++)//约定好，深度PID有7个字节，存放在数组0位
				CAN_Tx_PID[0].Data[i]= tcp_client_recvbuf[i+3];
				CAN_PID_Send_Point=&(CAN_Tx_PID[0]);//将数组0的指针传送给发送变量
			}
			else if(temp==0x12)//如果收到的是参数1的数据
			{
				CAN_Tx_PID[1].Data[7]=0xaa;			
				for(i=0;i<7;i++)//约定好，前进PID有7个字节，存放在数组1位
				CAN_Tx_PID[1].Data[i]= tcp_client_recvbuf[i+3];
				CAN_PID_Send_Point=&(CAN_Tx_PID[1]);//将数组1的指针传送给发送变量		
			}
			else if(temp==0x22)//如果收到的是参数2的数据
			{
				CAN_Tx_PID[1].Data[7]=0x55;		
				for(i=0;i<7;i++)//约定好，前进PID有7个字节，存放在数组1位
				CAN_Tx_PID[1].Data[i]= tcp_client_recvbuf[i+3];
				CAN_PID_Send_Point=&(CAN_Tx_PID[1]);//将数组1的指针传送给发送变量			
			
			}
			else if(temp==0x14)//如果收到的是参数1的数据
			{
				CAN_Tx_PID[2].Data[7]=0xaa;
				for(i=0;i<7;i++)//约定好，侧移PID有7个字节，存放在数组2位
				CAN_Tx_PID[2].Data[i]= tcp_client_recvbuf[i+3];
				CAN_PID_Send_Point=&(CAN_Tx_PID[2]);//将数组2的指针传送给发送变量
			}
			else if(temp==0x24)//如果收到的是参数2的数据
			{
				CAN_Tx_PID[2].Data[7]=0x55;	
				for(i=0;i<7;i++)//约定好，侧移PID有7个字节，存放在数组2位
				CAN_Tx_PID[2].Data[i]= tcp_client_recvbuf[i+3];
				CAN_PID_Send_Point=&(CAN_Tx_PID[2]);//将数组2的指针传送给发送变量		
			}
			else if(temp==0x08)//如果收到静止PID
			{
				for(i=0;i<7;i++)//约定好，静止PID有7个字节，存放在数组3位
				CAN_Tx_PID[3].Data[i]= tcp_client_recvbuf[i+3];
				CAN_PID_Send_Point=&(CAN_Tx_PID[3]);//将数组3的指针传送给发送变量				
			}
			else if(temp==0xff)//表示需要发送写flash信号
			{
				CAN_Tx_PID[4].Data[0]=0xaa;	
				CAN_PID_Send_Point=&(CAN_Tx_PID[4]);//将数组2的指针传送给发送变量		
			}
/*************************************************************************************/			
			PID_Receive_Flg=0xff;//标记已经收到数据并处理好了	，这是给应用程序的通知
//		}	//奇偶校验		
		}
		tcp_client_flag&=~(1<<6);//标记数据已经被处理了.这是给LWIP系统的通知
	}
	
	if(tcp_client_flag&1<<5)//是否连接上
	{
		LED1=0;
	}else if((tcp_client_flag&1<<5)==0)//未连接上则灭灯，报警
	{
		LED1=1;
	}
	if(Connect_Count>=300)//3000ms判断一次是否连接断开，如果断开，就重连
	{
		if((tcp_client_flag&1<<5)==0)
			{
				tcp_client_connection_close(tcppcb,0);//关闭连接
				tcppcb=tcp_new();	//创建一个新的pcb
				if(tcppcb)			//创建成功
				{ 
					IP4_ADDR(&rmtipaddr,lwipdev.remoteip[0],lwipdev.remoteip[1],lwipdev.remoteip[2],lwipdev.remoteip[3]); 
					tcp_connect(tcppcb,&rmtipaddr,TCP_CLIENT_PORT,tcp_client_connected);//连接到目的地址的指定端口上,当连接成功后回调tcp_client_connected()函数

				}
			}

	}


}

//lwIP TCP连接建立后调用回调函数
err_t tcp_client_connected(void *arg, struct tcp_pcb *tpcb, err_t err)
{
	struct tcp_client_struct *es=NULL;  
	if(err==ERR_OK)   
	{
		es=(struct tcp_client_struct*)mem_malloc(sizeof(struct tcp_client_struct));  //申请内存
		if(es) //内存申请成功
		{
 			es->state=ES_TCPCLIENT_CONNECTED;//状态为连接成功
			es->pcb=tpcb;  
			es->p=NULL; 
			tcp_arg(tpcb,es);        			//使用es更新tpcb的callback_arg
			tcp_recv(tpcb,tcp_client_recv);  	//初始化LwIP的tcp_recv回调功能   
			tcp_err(tpcb,tcp_client_error); 	//初始化tcp_err()回调函数
			tcp_sent(tpcb,tcp_client_sent);		//初始化LwIP的tcp_sent回调功能
			tcp_poll(tpcb,tcp_client_poll,1); 	//初始化LwIP的tcp_poll回调功能 
 			tcp_client_flag|=1<<5; 				//标记连接到服务器了
			err=ERR_OK;
		}else
		{ 
			tcp_client_connection_close(tpcb,es);//关闭连接
			err=ERR_MEM;	//返回内存分配错误
		}
	}else
	{
		tcp_client_connection_close(tpcb,0);//关闭连接
	}
	return err;
}
    
//lwIP tcp_recv()函数的回调函数
err_t tcp_client_recv(void *arg,struct tcp_pcb *tpcb,struct pbuf *p,err_t err)
{ 
	u32 data_len = 0;
	struct pbuf *q;
	struct tcp_client_struct *es;
	err_t ret_err; 
	LWIP_ASSERT("arg != NULL",arg != NULL);
	es=(struct tcp_client_struct *)arg; 
	if(p==NULL)//如果从服务器接收到空的数据帧就关闭连接
	{
		es->state=ES_TCPCLIENT_CLOSING;//需要关闭TCP 连接了 
 		es->p=p; 
		ret_err=ERR_OK;
	}else if(err!= ERR_OK)//当接收到一个非空的数据帧,但是err!=ERR_OK
	{ 
		if(p)pbuf_free(p);//释放接收pbuf
		ret_err=err;
	}else if(es->state==ES_TCPCLIENT_CONNECTED)	//当处于连接状态时
	{
		if(p!=NULL)//当处于连接状态并且接收到的数据不为空时
		{
			memset(tcp_client_recvbuf,0,TCP_CLIENT_RX_BUFSIZE);  //数据接收缓冲区清零
			for(q=p;q!=NULL;q=q->next)  //遍历完整个pbuf链表
			{
				//判断要拷贝到TCP_CLIENT_RX_BUFSIZE中的数据是否大于TCP_CLIENT_RX_BUFSIZE的剩余空间，如果大于
				//的话就只拷贝TCP_CLIENT_RX_BUFSIZE中剩余长度的数据，否则的话就拷贝所有的数据
				if(q->len > (TCP_CLIENT_RX_BUFSIZE-data_len)) memcpy(tcp_client_recvbuf+data_len,q->payload,(TCP_CLIENT_RX_BUFSIZE-data_len));//拷贝数据
				else memcpy(tcp_client_recvbuf+data_len,q->payload,q->len);
				data_len += q->len;  	
				if(data_len > TCP_CLIENT_RX_BUFSIZE) break; //超出TCP客户端接收数组,跳出	
			}
			tcp_client_flag|=1<<6;		//标记接收到数据了
 			tcp_recved(tpcb,p->tot_len);//用于获取接收数据,通知LWIP可以获取更多数据
			pbuf_free(p);  	//释放内存
			ret_err=ERR_OK;
		}
	}else  //接收到数据但是连接已经关闭,
	{ 
		tcp_recved(tpcb,p->tot_len);//用于获取接收数据,通知LWIP可以获取更多数据
		es->p=NULL;
		pbuf_free(p); //释放内存
		ret_err=ERR_OK;
	}
	return ret_err;
}
//lwIP tcp_err函数的回调函数
void tcp_client_error(void *arg,err_t err)
{  
	//这里我们不做任何处理
} 

//lwIP tcp_poll的回调函数
err_t tcp_client_poll(void *arg, struct tcp_pcb *tpcb)
{
	err_t ret_err;
	struct tcp_client_struct *es; 
	es=(struct tcp_client_struct*)arg;
	if(es!=NULL)  //连接处于空闲可以发送数据
	{
		if(tcp_client_flag&(1<<7))	//判断是否有数据要发送 
		{
			es->p=pbuf_alloc(PBUF_TRANSPORT,TCP_Send_Buf_Size,PBUF_POOL);	//申请内存  strlen((char*)TCP_Send_Buf)
			pbuf_take(es->p,(char*)TCP_Send_Buf,TCP_Send_Buf_Size);	//将tcp_client_sentbuf[]中的数据拷贝到es->p_tx中strlen((char*)TCP_Send_Buf)
			tcp_client_senddata(tpcb,es);//将tcp_client_sentbuf[]里面复制给pbuf的数据发送出去
			tcp_client_flag&=~(1<<7);	//清除数据发送标志
			if(es->p)pbuf_free(es->p);	//释放内存
		}else if(es->state==ES_TCPCLIENT_CLOSING)
		{ 
 			tcp_client_connection_close(tpcb,es);//关闭TCP连接
		} 
		ret_err=ERR_OK;
	}else
	{ 
		tcp_abort(tpcb);//终止连接,删除pcb控制块
		ret_err=ERR_ABRT;
	}
	return ret_err;
} 
//lwIP tcp_sent的回调函数(当从远端主机接收到ACK信号后发送数据)
err_t tcp_client_sent(void *arg, struct tcp_pcb *tpcb, u16_t len)
{
	struct tcp_client_struct *es;
	LWIP_UNUSED_ARG(len);
	es=(struct tcp_client_struct*)arg;
	if(es->p)tcp_client_senddata(tpcb,es);//发送数据
	return ERR_OK;
}
//此函数用来发送数据
void tcp_client_senddata(struct tcp_pcb *tpcb, struct tcp_client_struct * es)
{
	struct pbuf *ptr; 
 	err_t wr_err=ERR_OK;
	while((wr_err==ERR_OK)&&es->p&&(es->p->len<=tcp_sndbuf(tpcb)))
	{
		ptr=es->p;
		wr_err=tcp_write(tpcb,ptr->payload,ptr->len,1); //将要发送的数据加入到发送缓冲队列中
		if(wr_err==ERR_OK)
		{  
			es->p=ptr->next;			//指向下一个pbuf
			if(es->p)pbuf_ref(es->p);	//pbuf的ref加一
			pbuf_free(ptr);				//释放ptr 
		}else if(wr_err==ERR_MEM)es->p=ptr;
//		tcp_output(tpcb);		//将发送缓冲队列中的数据立即发送出去
	} 	
} 
//关闭与服务器的连接
void tcp_client_connection_close(struct tcp_pcb *tpcb, struct tcp_client_struct * es)
{
	if(tpcb!=NULL)//如果没有被删除的话，判断下以免产生错误
	{
		//移除回调
		tcp_arg(tpcb,NULL);  
		tcp_recv(tpcb,NULL);
		tcp_sent(tpcb,NULL);
		tcp_err(tpcb,NULL);
		tcp_poll(tpcb,NULL,0); 
		
		tcp_abort(tpcb);//终止连接,删除pcb控制块	
		if(es)mem_free(es); 
	}
	tcp_client_flag&=~(1<<5);//标记连接断开了
}




#include "data.h"
#include "can.h"


u8 SEN1_Water_Waring=0;
u8 SEN2_Water_Waring=0;



u8 TCP_Send_Flg=0;
/*向服务器发送数据包*/
u8 TCP_Receive_Flg=0;

u8 TCP_Send_Buf[TCP_Send_Buf_Size];
/*用于向下发送控制命令的缓冲包*/
CanTxMsg CAN_Tx_Commond[10];
/*用于向下发送PID参数值*/
CanTxMsg CAN_Tx_PID[5];
/*Can发送控制命令的发送队列指针*/
CanTxMsg * CAN_Tx_Queues[10];
CanTxMsg * CAN_PID_Send_Point;
u8 PID_Receive_Flg=0;

u16 Connect_Count;

/*重置队列指针为NULL*/
void CAN_Tx_Queues_Reset(void)
{
	u8 i;
	for(i=0;i<10;i++)
	CAN_Tx_Queues[i]=NULL;
}
//发送数据帧的固定初始化
void CAN_Tx_Commond_Init(void)
{
	u8 i;
	for(i=0;i<10;i++)//统一赋值，为标准帧，数据帧
	{
		CAN_Tx_Commond[i].IDE=CAN_Id_Standard;
		CAN_Tx_Commond[i].RTR=CAN_RTR_Data;	
	}
	CAN_Tx_Commond[0].StdId=SEN1_LED_PWM_ID;//0位被用来传递sensor1的LED_PWM
	CAN_Tx_Commond[0].DLC=2;//两位数据
	
	CAN_Tx_Commond[1].StdId=SEN2_LED_PWM_ID;//1位被用来传递sensor2的LED_PWM
	CAN_Tx_Commond[1].DLC=2;//两位数据
	
	CAN_Tx_Commond[2].StdId=SEN1_Servo1_Position_ID;//2位被用来传递sensor1的servo1
	CAN_Tx_Commond[2].DLC=2;	
	
	CAN_Tx_Commond[3].StdId=SEN2_Servo1_Position_ID;//3位被用来传递sensor2的servo1
	CAN_Tx_Commond[3].DLC=2;
/************************************************************************88***************/	
	CAN_Tx_Commond[4].StdId=SEN1_Servo2_Position_ID;//4位被用来传递sensor2的servo1
	CAN_Tx_Commond[4].DLC=2;	
	
	CAN_Tx_Commond[5].StdId=SEN2_Servo2_Position_ID;//5位被用来传递sensor2的servo2
	CAN_Tx_Commond[5].DLC=2;
	
	CAN_Tx_Commond[6].StdId=DR_Servo1_Position_ID;//6位被用来传递Driver的servo1
	CAN_Tx_Commond[6].DLC=2;
	
	CAN_Tx_Commond[7].StdId=DR_Servo2_Position_ID;//7位被用来传递Driver的servo2
	CAN_Tx_Commond[7].DLC=2;	
/*****************************************************************************************/

	CAN_Tx_Commond[8].StdId=DR_Motor_Speed_ID;//8位被用来传递Driver的运动参数
	CAN_Tx_Commond[8].DLC=6;//6个字节包含控制模式和操作模式

}
/*
*
*发送PID参数
*/
void CAN_Tx_PID_Init(void)
{
	u8 i;
	for(i=0;i<3;i++)//统一赋值，为标准帧，数据帧
	{
		CAN_Tx_PID[i].IDE=CAN_Id_Standard;
		CAN_Tx_PID[i].RTR=CAN_RTR_Data;	
	}
	CAN_Tx_PID[0].StdId=DR_DEEP_PID_ID;//0位被用来传递深度PID参数
	CAN_Tx_PID[0].DLC=7;//7位数据
	
	CAN_Tx_PID[1].StdId=DR_FB_PID_ID;//1位被用来传递前进PID参数
	CAN_Tx_PID[1].DLC=8;//8位数据
	
	CAN_Tx_PID[2].StdId=DR_SW_PID_ID;//2位被用来传递侧移PID参数
	CAN_Tx_PID[2].DLC=8;	
	
	CAN_Tx_PID[3].StdId=DR_STATIC_PID_ID;//3位被用来传递静止PID
	CAN_Tx_PID[3].DLC=7;	
	
	CAN_Tx_PID[4].StdId=DR_WRITE_FLASH_ID;//4位被用来传递写flash信号
	CAN_Tx_PID[4].DLC=1;	
	
}

/*
*异或校验
*
*
*/
u8 XOR_Verify(u8 * data,u8 size) //求异或校验和
{
	u8 temp,i;
	temp = data[0];//获取第一位数据，异或校验从头部开始
	for(i = 1;i<size-1;i++)
	{
		temp = temp^data[i]; //相邻逐次按位异或
	}
	return temp;
}
/**
*函数功能：
*下位机向上位机发送数据的初始化
*
*
*/
void TCP_Send_Buf_Init(void)
{
	u8 i;
	for(i=0;i<TCP_Send_Buf_Size;i++)
		TCP_Send_Buf[i]=0;//先清零
	TCP_Send_Buf[0]=TCP_Send_Buf[1]=0xFE;//帧头
	TCP_Send_Buf[26]=TCP_Send_Buf[27]=0xFD;//帧尾
}


#ifndef __DATA_H
#define __DATA_H	 
#include "sys.h"	

#ifndef NULL
#define NULL 0
#endif

#define TCP_Send_Buf_Size  28
#define TCP_Receive_Buf_Size 27
extern u8 SEN1_Water_Waring;
extern u8 SEN2_Water_Waring;


extern u8 TCP_Send_Buf[TCP_Send_Buf_Size];
extern u8 TCP_Send_Flg;
extern u8 TCP_Receive_Flg;

extern u16 Connect_Count;
/*用于向下发送控制命令的缓冲包*/
extern CanTxMsg CAN_Tx_Commond[10];
/*用于向下发送PID参数值*/
extern CanTxMsg CAN_Tx_PID[5];
/*Can发送控制命令的发送队列指针*/
extern CanTxMsg * CAN_Tx_Queues[10];
extern CanTxMsg * CAN_PID_Send_Point;
extern u8 PID_Receive_Flg;

void CAN_Tx_Queues_Reset(void);
void CAN_Tx_Commond_Init(void);
void CAN_Tx_PID_Init(void);
u8 XOR_Verify(u8 * data,u8 size); //求异或校验和
void TCP_Send_Buf_Init(void);


#endif



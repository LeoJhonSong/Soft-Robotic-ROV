%%
% version 2.0
% created by Jiaqi Liu

% Added: 
%        Single channel pressure input

function varargout = AutoCapture(varargin)
% AUTOCAPTURE MATLAB code for AutoCapture.fig
%      AUTOCAPTURE, by itself, creates a new AUTOCAPTURE or raises the existing
%      singleton*.
%
%      H = AUTOCAPTURE returns the handle to a new AUTOCAPTURE or the handle to
%      the existing singleton*.
%
%      AUTOCAPTURE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in AUTOCAPTURE.M with the given input arguments.
%
%      AUTOCAPTURE('Property','Value',...) creates a new AUTOCAPTURE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before AutoCapture_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to AutoCapture_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help AutoCapture

% Last Modified by GUIDE v2.5 19-Aug-2019 13:26:54

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @AutoCapture_OpeningFcn, ...
                   'gui_OutputFcn',  @AutoCapture_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before AutoCapture is made visible.
function AutoCapture_OpeningFcn(hObject, ~, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to AutoCapture (see VARARGIN)

% Choose default command line output for AutoCapture
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes AutoCapture wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% channel 1-do1
% channel 2-do2
% channel 3-do3
% channel 4.5.6-do4
% channel 7.8.9-do5
% channel 10-do6
% vaccum pump-do7

global waterpressure;
waterpressure = 0;
global OdA;
OdA = [0;1e-8;-325];
global d;
d = 48;
global stepLength;
stepLength = 10;
global opendo1;
global opendo2;
global opendo3;
global opendo4;
global opendo5;
global opendo6;
global opendo7;
global opendo8;
global openall;
opendo1 = uint8([ 254, 5, 0, 0, 255, 0, 152, 53] ); %FE 05 00 00 FF 00 98 35 
opendo2 = uint8([ 254, 5, 0, 1, 255, 0, 201, 245]); %FE 05 00 01 FF 00 C9 F5
opendo3 = uint8([ 254, 5, 0, 2, 255, 0, 57, 245] ); %FE 05 00 02 FF 00 39 F5
opendo4 = uint8([ 254, 5, 0, 3, 255, 0, 104, 53] ); %FE 05 00 03 FF 00 68 35
opendo5 = uint8([ 254, 5, 0, 4, 255, 0, 217, 244]); %FE 05 00 04 FF 00 D9 F4
opendo6 = uint8([ 254, 5, 0, 5, 255, 0, 136, 52] ); %FE 05 00 05 FF 00 88 34
opendo7 = uint8([ 254, 5, 0, 6, 255, 0, 120, 52] ); %FE 05 00 06 FF 00 78 34
opendo8 = uint8([ 254, 5, 0, 7, 255, 0, 41, 244] ); %FE 05 00 07 FF 00 29 F4
openall = uint8([ 254, 15, 0, 0, 0, 8, 1, 255, 241, 209] ); %FE 0F 00 00 00 08 01 FF F1 D1

global closedo1;
global closedo2;
global closedo3;
global closedo4;
global closedo5;
global closedo6;
global closedo7;
global closedo8;
global closeall;
closedo1 = uint8([254, 5, 0, 0, 0, 0, 217, 197]); %FE 05 00 00 00 00 D9 C5
closedo2 = uint8([254, 5, 0, 1, 0, 0, 136, 5]  ); %FE 05 00 01 00 00 88 05
closedo3 = uint8([254, 5, 0, 2, 0, 0, 120, 5]  ); %FE 05 00 02 00 00 78 05
closedo4 = uint8([254, 5, 0, 3, 0, 0, 41, 197] ); %FE 05 00 03 00 00 29 C5
closedo5 = uint8([254, 5, 0, 4, 0, 0, 152, 4]  ); %FE 05 00 04 00 00 98 04
closedo6 = uint8([254, 5, 0, 5, 0, 0, 201, 196]); %FE 05 00 05 00 00 C9 C4
closedo7 = uint8([254, 5, 0, 6, 0, 0, 57, 196] ); %FE 05 00 06 00 00 39 C4
closedo8 = uint8([254, 5, 0, 7, 0, 0, 104, 4]  ); %FE 05 00 07 00 00 68 04
closeall = uint8([254, 15, 0, 0, 0, 8, 1, 0, 177, 145]); %FE 0F 00 00 00 08 01 00 B1 91

% global command;
% global command_addr;
% global command_registername;
% global command_registeraddrH;
% global command_registeraddrL;
% global command_OutputNumH;
% global command_OutputNumL;
% global command_bytenum;
% global aucCRCHi;
% global aucCRCLo;
% command_addr = uint8(254); %0xFE
% command_registername = uint8(16); %0x10
% command_registeraddrH = uint8(0); %0x00
% command_registeraddrL = uint8(0); %0x00
% command_OutputNumH = uint8(0); %0x00
% command_OutputNumL = uint8(10);%0x0a
% command_bytenum = uint8(20); %0x14
% aucCRCHi = uint8([ 0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64 ]);
% aucCRCLo = uint8([ 0;192;193;1;195;3;2;194;198;6;7;199;5;197;196;4;204;12;13;205;15;207;206;14;10;202;203;11;201;9;8;200;216;24;25;217;27;219;218;26;30;222;223;31;221;29;28;220;20;212;213;21;215;23;22;214;210;18;19;211;17;209;208;16;240;48;49;241;51;243;242;50;54;246;247;55;245;53;52;244;60;252;253;61;255;63;62;254;250;58;59;251;57;249;248;56;40;232;233;41;235;43;42;234;238;46;47;239;45;237;236;44;228;36;37;229;39;231;230;38;34;226;227;35;225;33;32;224;160;96;97;161;99;163;162;98;102;166;167;103;165;101;100;164;108;172;173;109;175;111;110;174;170;106;107;171;105;169;168;104;120;184;185;121;187;123;122;186;190;126;127;191;125;189;188;124;180;116;117;181;119;183;182;118;114;178;179;115;177;113;112;176;80;144;145;81;147;83;82;146;150;86;87;151;85;149;148;84;156;92;93;157;95;159;158;94;90;154;155;91;153;89;88;152;136;72;73;137;75;139;138;74;78;142;143;79;141;77;76;140;68;132;133;69;135;71;70;134;130;66;67;131;65;129;128;64]);
% command = [command_addr,command_registername,command_registeraddrH,command_registeraddrL, command_bytenum,];


% --- Outputs from this function are returned to the command line.
function varargout = AutoCapture_OutputFcn(~, ~, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton_ON.
function pushbutton_ON_Callback(~, ~, handles)
% hObject    handle to pushbutton_ON (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global dotcp;
global datcp;

if strcmp( get(handles.pushbutton_ON, 'string'), 'ON')    

%     daip_address = '192.168.1.234';
        daip_address = '192.168.1.231';
    daip_port = int16(10000);
    datcp = tcpip(daip_address, daip_port);
    datcp.OutputBuffersize=100000;
    fopen(datcp);
    
%     doip_address = '192.168.1.232';
        doip_address = '192.168.1.254';
    doip_port = int16(10001);
    dotcp = tcpip(doip_address, doip_port);
    dotcp.OutputBuffersize=100000;
    fopen(dotcp);
    
    set(handles.text_dastatus, 'string', 'DA Converter: ON');
    set(handles.text_dostatus, 'string', 'Relay : ON');
    set(handles.pushbutton_ON, 'string', 'OFF');
 
elseif strcmp( get(handles.pushbutton_ON, 'string'), 'OFF')
    fclose(datcp);  
    delete(datcp);    
    fclose(dotcp);     
    delete(dotcp); 
    set(handles.text_dastatus, 'string', 'DA Converter: OFF');
    set(handles.text_dostatus, 'string', 'Relay : OFF');
    set(handles.pushbutton_ON, 'string', 'ON');
end


% --- Executes on button press in pushbutton_autocapture.
function pushbutton_autocapture_Callback(hObject, ~, handles)
% hObject    handle to pushbutton_autocapture (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global g;

if strcmp( get(handles.pushbutton_autocapture, 'string'), 'AutoCapture : OFF')
    set(handles.pushbutton_autocapture, 'String', 'AutoCapture : ON');
    g = serial('com3');
    
    set(g,'BaudRate',115200);  %%% Baud rate
    set(g,'DataBits',8);     %%% DataBits 
    set(g,'StopBits',1);     %%% StopBits
    set(g,'InputBufferSize',1024000);%%%  
    set(g,'BytesAvailableFcnMode','byte');
    set(g,'BytesAvailableFcnCount',6);
    g.BytesAvailableFcn ={@ReceiveCallback,hObject,handles};
    fopen(g);

else
    fclose(g);
    delete(g);
    set(handles.pushbutton_autocapture, 'String', 'AutoCapture : OFF');
end
 
function ReceiveCallback(obj,eventdata,hObject,handles)

global d;
global waterpressure;

    deltax = str2double(get(handles.edit_kx,'String'));
    deltay = str2double(get(handles.edit_ky,'String'));
    out = fread (obj, 6,'char');
    set(handles.text_xpixel, 'String', [ 'X_p : ', num2str(50 - ( out(2) + out(4) )/2)] );
    set(handles.text_ypixel, 'String', [ 'Y_p : ', num2str(50 - ( out(3) + out(5) )/2)] );

    x = ( 50 - ( out(2) + out(4) )/2) * deltax;
    y = ( 100 - ( out(3) + out(5) )/2 ) * deltay;
    z = - 400;
    
    waterpressure = out(6) - 6;
    set(handles.edit_waterpressure,'String', num2str(out(6)) );
    
    set(handles.text_x, 'String',  ['X : ', num2str(x)] );
    set(handles.text_y, 'String',  ['Y : ', num2str(y)] );

    [ L1d(1), L1d(2), L1d(3), Ld3 ] = fInverseSimplified( x, y, z, d );
 
if ~fIsOverSpace( L1d(1), L1d(2), L1d(3), Ld3, handles )
    pushbutton_Vaccum_Callback(hObject, eventdata, handles);
    pause(2);
    pushbutton_foldseg3_Callback(hObject, eventdata, handles);
    pause(4);
    fDrivingSegments( L1d(1), L1d(2), L1d(3), Ld3, out(1)-111, handles);
    pause(8);
%     pushbutton_Vaccum_Callback(hObject, eventdata, handles);
%     pause(2);
    pushbutton_foldseg3_Callback(hObject, eventdata, handles);
    pause(18);
    pushbutton_Grasp_Callback(hObject, eventdata, handles);
    pause(5);
    pushbutton_foldseg3_Callback(hObject, eventdata, handles);
    pause(6);
    pushbutton_Collect03_Callback(hObject, eventdata, handles);
    pause(5);
    pushbutton_foldseg3_Callback(hObject, eventdata, handles);
    pause(6);
    pushbutton_Vaccum_Callback(hObject, eventdata, handles);
    pause(4);
    pushbutton_Release_Callback(hObject, eventdata, handles);
    pause(0.5);
    pushbutton_back_Callback(hObject, eventdata, handles);
    pause(0.5);
else
            warndlg('Final point is OUT of workspase!','Warning');
            return;
end
    
% --- Executes on button press in pushbutton_Pressureset.
function pushbutton_Pressureset_Callback(~, ~, handles)
% hObject    handle to pushbutton_Pressureset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global waterpressure;
    waterpressure = str2double(get(handles.edit_waterpressure,'string'));
pressure  =[    str2double(get(handles.edit_Ps1,'string')),...
                str2double(get(handles.edit_Ps2,'string')),...
                str2double(get(handles.edit_Ps3,'string')),...
                str2double(get(handles.edit_Ps4,'string')),...
                str2double(get(handles.edit_Ps5,'string')),...
                str2double(get(handles.edit_Ps6,'string')),...
                str2double(get(handles.edit_Ps7,'string')),...
                str2double(get(handles.edit_Ps8,'string')),...
                str2double(get(handles.edit_Ps9,'string')),...
                str2double(get(handles.edit_Ps10,'string')),...
                ];
PressureSend( pressure + waterpressure, handles );


% --- Executes on button press in pushbutton_Release.
function pushbutton_Release_Callback(~, ~, handles)
% hObject    handle to pushbutton_Release (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global dotcp;
global closeall;
global OdA

pressure = zeros(1, 10);
PressureSend(pressure,handles); 
fwrite(dotcp, closeall(1,:), 'char');
OdA = [0;1e-8;-325];

set(handles.pushbutton_foldseg3, 'String', 'Fold');
set(handles.pushbutton_Vaccum, 'String', 'Vaccum');
set(handles.pushbutton_Grasp, 'String', 'Grasp');
set(handles.text_ManualX, 'String', ['X: ',num2str(OdA(1))]);
set(handles.text_ManualY, 'String', ['Y: ',int2str(OdA(2))]);
set(handles.text_ManualZ, 'String', ['Z: ',num2str(OdA(3))]);

% --- Executes on button press in pushbutton_back.
function pushbutton_back_Callback(~, ~, handles)
% hObject    handle to pushbutton_back (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
pressure = zeros(1,10);
pressure(2) = 100;
pressure(3) = 80;
pressure(10) = 30;
PressureSend(pressure,handles);

% --- Executes on button press in pushbutton_foldseg3.
function pushbutton_foldseg3_Callback(~, ~, handles)
% hObject    handle to pushbutton_foldseg3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global dotcp;
global opendo5;
global opendo7;
global closedo7;
global closedo5;
if strcmp( get(handles.pushbutton_foldseg3, 'string'), 'Fold')
    set(handles.pushbutton_foldseg3, 'String', 'F:ON');
    fwrite(dotcp,opendo7(1,:),'char');
    pause(0.02);
    fwrite(dotcp,opendo5(1,:),'char');
elseif strcmp( get(handles.pushbutton_foldseg3, 'string'), 'F:ON')
    set(handles.pushbutton_foldseg3, 'String', 'Fold');
    fwrite(dotcp,closedo7(1,:),'char');
    pause(0.02);
    fwrite(dotcp,closedo5(1,:),'char');
end


% --- Executes on button press in pushbutton_Vaccum.
function pushbutton_Vaccum_Callback(~, ~, handles)
% hObject    handle to pushbutton_Vaccum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global dotcp;
global opendo6;
global opendo7;
global closedo7;
global closedo6;
if strcmp( get(handles.pushbutton_Vaccum, 'string'), 'V:ON')
    set(handles.pushbutton_Vaccum, 'String', 'Vaccum');
    fwrite(dotcp,closedo7(1,:),'char');
    pause(0.02);
    fwrite(dotcp,closedo6(1,:),'char');
    
elseif strcmp( get(handles.pushbutton_Vaccum, 'string'), 'Vaccum')
    fwrite(dotcp,opendo7(1,:),'char');
    pause(0.02);
    fwrite(dotcp,opendo6(1,:),'char');
    set(handles.pushbutton_Vaccum, 'String', 'V:ON');

end


% --- Executes on button press in pushbutton_Grasp.
function pushbutton_Grasp_Callback(hObject, ~, handles)
% hObject    handle to pushbutton_Grasp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global waterpressure;
waterpressure = str2double(get(handles.edit_waterpressure,'string'));
if strcmp( get(handles.pushbutton_Grasp, 'string'), 'Grasp')
    if strcmp( get(handles.pushbutton_Vaccum, 'string'), 'V:ON')
     pushbutton_Vaccum_Callback(hObject, 0, handles);
    end
    set(handles.pushbutton_Vaccum, 'String', 'Vaccum');
%      pressure  =[   str2double(get(handles.edit_Ps1,'string')),...
%                     str2double(get(handles.edit_Ps2,'string')),...
%                     str2double(get(handles.edit_Ps3,'string')),...
%                     str2double(get(handles.edit_Ps4,'string')),...
%                     str2double(get(handles.edit_Ps5,'string')),...
%                     str2double(get(handles.edit_Ps6,'string')),...
%                     str2double(get(handles.edit_Ps7,'string')),...
%                     str2double(get(handles.edit_Ps8,'string')),...
%                     str2double(get(handles.edit_Ps9,'string')),...
%                     60,...
%                     ];
%     pressure1 = pressure;
%     pressure1(10) = pressure1(10)*1.5 + waterpressure;
%     PressureSend( pressure1  ,handles);
%     pause(0.2);
%     pressure(10) = pressure(10) + waterpressure;
    PressureSendSingle( 10, 60 + waterpressure ,handles );   
    set(handles.pushbutton_Grasp, 'String', 'G:ON');
 elseif strcmp( get(handles.pushbutton_Grasp, 'string'), 'G:ON')
%      pressure  =[   str2double(get(handles.edit_Ps1,'string')),...
%                     str2double(get(handles.edit_Ps2,'string')),...
%                     str2double(get(handles.edit_Ps3,'string')),...
%                     str2double(get(handles.edit_Ps4,'string')),...
%                     str2double(get(handles.edit_Ps5,'string')),...
%                     str2double(get(handles.edit_Ps6,'string')),...
%                     str2double(get(handles.edit_Ps7,'string')),...
%                     str2double(get(handles.edit_Ps8,'string')),...
%                     str2double(get(handles.edit_Ps9,'string')),...
%                     0,...
%                     ];
     PressureSendSingle( 10, 0 ,handles); 
     set(handles.pushbutton_Grasp, 'String', 'Grasp');    
end


% --- Executes on button press in pushbutton_Collect01.
function pushbutton_Collect01_Callback(~, ~,handles)
% hObject    handle to pushbutton_Collect01 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global waterpressure;
waterpressure = str2double(get(handles.edit_waterpressure,'string'));
    pressure = [ 0; 100; 100; 100; 0; 60; 45; 0; 0; 60 ];
    pressure1 = pressure*1.5;
    PressureSend( pressure1 + waterpressure  ,handles);
    pause(0.2);
    PressureSend( pressure + waterpressure ,handles); 

% --- Executes on button press in pushbutton_Collect02.
function pushbutton_Collect02_Callback(~, ~,handles)
% hObject    handle to pushbutton_Collect02 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global waterpressure;
    waterpressure = str2double(get(handles.edit_waterpressure,'string'));
    pressure = [ 0; 120; 120; 100; 0; 100; 45; 0; 0; 60 ];
    pressure1 = pressure*1.5;
    PressureSend( pressure1 + waterpressure ,handles);
    pause(0.2);
    PressureSend( pressure + waterpressure,handles); 

% --- Executes on button press in pushbutton_Collect03.
function pushbutton_Collect03_Callback(~, ~,handles)
% hObject    handle to pushbutton_Collect03 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
for i = 1:4  
    PressureSendSingle( 10, 10,handles );
    pause(0.08);
    PressureSendSingle( 10, 60,handles );
end

% --- Executes on button press in pushbutton_XH.
function pushbutton_XH_Callback(~, ~, handles)
% hObject    handle to pushbutton_XH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ManualControl('X+', handles);

% --- Executes on button press in pushbutton_XL.
function pushbutton_XL_Callback(~, ~, handles)
% hObject    handle to pushbutton_XL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ManualControl('X-', handles);

% --- Executes on button press in pushbutton_YH.
function pushbutton_YH_Callback(~, ~, handles)
% hObject    handle to pushbutton_YH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ManualControl('Y+', handles);

% --- Executes on button press in pushbutton_YL.
function pushbutton_YL_Callback(~, ~, handles)
% hObject    handle to pushbutton_YL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ManualControl('Y-', handles);

% --- Executes on button press in pushbutton_ZH.
function pushbutton_ZH_Callback(~, ~, handles)
% hObject    handle to pushbutton_ZH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ManualControl('Z+', handles);

% --- Executes on button press in pushbutton_ZL.
function pushbutton_ZL_Callback(~, ~, handles)
% hObject    handle to pushbutton_ZL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ManualControl('Z-', handles);

% --- Executes on key press with focus on checkbox_KeyboardCtrl and none of its controls.
function checkbox_KeyboardCtrl_KeyPressFcn(hObject, ~, handles)
% hObject    handle to checkbox_KeyboardCtrl (see GCBO)
% ~  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
global stepLength;
if(get(hObject,'Value'))
    if      get(gcf,'CurrentCharacter') == 100      % 'd', X+
        ManualControl('X-', handles);
    elseif  get(gcf,'CurrentCharacter') == 97       % 'a', X-
        ManualControl('X+', handles);
    elseif  get(gcf,'CurrentCharacter') == 119      % 'w', Y+
        ManualControl('Y+', handles);
    elseif  get(gcf,'CurrentCharacter') == 115      % 's', Y-
        ManualControl('Y-', handles);
    elseif  get(gcf,'CurrentCharacter') == 113       % 'q', Z+
        ManualControl('Z+', handles);
    elseif  get(gcf,'CurrentCharacter') == 101       % 'e', Z-
        ManualControl('Z-', handles);
    elseif  get(gcf,'CurrentCharacter') == 92        % '\', vaccum
        pushbutton_Vaccum_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 13        %  /r, grasp
        pushbutton_Grasp_Callback(hObject, 0, handles);
%     elseif  get(gcf,'CurrentCharacter') == 8         %  bs, release gripper
%         pushbutton_GripperRelease_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 8        % backspace, reset
        pushbutton_Release_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 102       % 'f', enlongation folding
        pushbutton_foldseg3_Callback(hObject, 0, handles);
%     elseif  get(gcf,'CurrentCharacter') == 112       % 'p', enlongation inflating
%         pushbutton_Enlongate_Callback(hObject, 0, handles);
%     elseif  get(gcf,'CurrentCharacter') == 105       % 'i', folding open
%         pushbutton_Fold_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 111       % 'o', s-collect
        pushbutton_Collect01_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 108       % 'l', l-collect
        pushbutton_Collect02_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 43        % '+', step length + 2
        stepLength = stepLength + 2;
        set(handles.edit_ManualStep, 'String', num2str(stepLength))
    elseif  get(gcf,'CurrentCharacter') == 45        % '-', step length - 2
        stepLength = max(1, stepLength - 2);
        set(handles.edit_ManualStep, 'String', num2str(stepLength))
    end  
%     pause(0.1);
end
    
function edit_kx_Callback(~, ~, ~)
% hObject    handle to edit_kx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_kx as text
%        str2double(get(hObject,'String')) returns contents of edit_kx as a double


% --- Executes during object creation, after setting all properties.
function edit_kx_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_kx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_ky_Callback(~, ~, ~)
% hObject    handle to edit_ky (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ky as text
%        str2double(get(hObject,'String')) returns contents of edit_ky as a double


% --- Executes during object creation, after setting all properties.
function edit_ky_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_ky (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_Ps1_Callback(~, ~, ~)
% hObject    handle to edit_Ps1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Ps1 as text
%        str2double(get(hObject,'String')) returns contents of edit_Ps1 as a double


% --- Executes during object creation, after setting all properties.
function edit_Ps1_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_Ps1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Ps2_Callback(~, ~, ~)
% hObject    handle to edit_Ps2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Ps2 as text
%        str2double(get(hObject,'String')) returns contents of edit_Ps2 as a double


% --- Executes during object creation, after setting all properties.
function edit_Ps2_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_Ps2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Ps3_Callback(~, ~, ~)
% hObject    handle to edit_Ps3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Ps3 as text
%        str2double(get(hObject,'String')) returns contents of edit_Ps3 as a double


% --- Executes during object creation, after setting all properties.
function edit_Ps3_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_Ps3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Ps4_Callback(~, ~, ~)
% hObject    handle to edit_Ps4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Ps4 as text
%        str2double(get(hObject,'String')) returns contents of edit_Ps4 as a double


% --- Executes during object creation, after setting all properties.
function edit_Ps4_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_Ps4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Ps6_Callback(~, ~, ~)
% hObject    handle to edit_Ps6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Ps6 as text
%        str2double(get(hObject,'String')) returns contents of edit_Ps6 as a double


% --- Executes during object creation, after setting all properties.
function edit_Ps6_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_Ps6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Ps7_Callback(~, ~, ~)
% hObject    handle to edit_Ps7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Ps7 as text
%        str2double(get(hObject,'String')) returns contents of edit_Ps7 as a double


% --- Executes during object creation, after setting all properties.
function edit_Ps7_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_Ps7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Ps8_Callback(~, ~, ~)
% hObject    handle to edit_Ps8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Ps8 as text
%        str2double(get(hObject,'String')) returns contents of edit_Ps8 as a double


% --- Executes during object creation, after setting all properties.
function edit_Ps8_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_Ps8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Ps9_Callback(~, ~, ~)
% hObject    handle to edit_Ps9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Ps9 as text
%        str2double(get(hObject,'String')) returns contents of edit_Ps9 as a double


% --- Executes during object creation, after setting all properties.
function edit_Ps9_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_Ps9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Ps5_Callback(~, ~, ~)
% hObject    handle to edit_Ps5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Ps5 as text
%        str2double(get(hObject,'String')) returns contents of edit_Ps5 as a double


% --- Executes during object creation, after setting all properties.
function edit_Ps5_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_Ps5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Ps10_Callback(~, ~, ~)
% hObject    handle to edit_Ps10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Ps10 as text
%        str2double(get(hObject,'String')) returns contents of edit_Ps10 as a double


% --- Executes during object creation, after setting all properties.
function edit_Ps10_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_Ps10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox_KeyboardCtrl.
function checkbox_KeyboardCtrl_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_KeyboardCtrl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_KeyboardCtrl



function edit_ManualStep_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ManualStep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ManualStep as text
%        str2double(get(hObject,'String')) returns contents of edit_ManualStep as a double


% --- Executes during object creation, after setting all properties.
function edit_ManualStep_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ManualStep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_waterpressure_Callback(hObject, eventdata, handles)
% hObject    handle to edit_waterpressure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_waterpressure as text
%        str2double(get(hObject,'String')) returns contents of edit_waterpressure as a double


% --- Executes during object creation, after setting all properties.
function edit_waterpressure_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_waterpressure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

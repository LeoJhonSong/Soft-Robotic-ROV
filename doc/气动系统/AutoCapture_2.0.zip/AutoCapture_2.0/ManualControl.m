function ManualControl(direction, handles)
global OdA;
global d;
global stepLength;
            stepLength = str2double(get(handles.edit_ManualStep,'string'));
            if     strcmp(direction, 'X+')
                OdA(1) = OdA(1) + stepLength +10;
            elseif strcmp(direction, 'X-')
                OdA(1) = OdA(1) - stepLength -10;
            elseif strcmp(direction, 'Y+')
                OdA(2) = OdA(2) + stepLength +10;
            elseif strcmp(direction, 'Y-')
                OdA(2) = OdA(2) - stepLength -10;
            elseif strcmp(direction, 'Z+')
                OdA(3) = OdA(3) + stepLength;
            elseif strcmp(direction, 'Z-')
                OdA(3) = OdA(3) - stepLength;
            end

            % distination parameters
            [ L1d(1), L1d(2), L1d(3), Ld3 ] = fInverseSimplified( OdA(1), OdA(2), OdA(3), d );
            % draw curvatures
            if ~fIsOverSpace( L1d(1), L1d(2), L1d(3), Ld3, handles )
                fDrivingSegments( L1d(1), L1d(2), L1d(3), Ld3, 0, handles );
                set(handles.text_ManualX, 'String', ['X: ', num2str(OdA(1))]);
                set(handles.text_ManualY, 'String', ['Y: ', num2str(OdA(2))]);
                set(handles.text_ManualZ, 'String', ['Z: ', num2str(OdA(3))]);
            else
                warndlg('Final point is OUT of workspase!','Warning');
                return;
            end
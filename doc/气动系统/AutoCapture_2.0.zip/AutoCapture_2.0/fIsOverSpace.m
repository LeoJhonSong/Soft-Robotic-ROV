function YN = fIsOverSpace( L1, L2, L3, L, handles )
% Trajectory Control of the underwater soft arm in opposing curvature
%   Included trajectories: Line, Circle in clockwise and anticlockwise, "8" shape.

% initial length
initLength = 107;
initLengthElg = 102;
% max length
maxLength = 440;
maxLengthElg = 360;

if (initLength < L1 && L1 < maxLength)...
        && (initLength < L2 && L2 < maxLength)...
        && (initLength < L3 && L3 < maxLength)...
        && (initLengthElg < L && L < maxLengthElg)
    YN = false; 
else
    YN = true;
end
% set(handles.edit_L1, 'String', num2str(L1));
% set(handles.edit_L2, 'String', num2str(L2));
% set(handles.edit_L3, 'String', num2str(L3));
% set(handles.edit_L4, 'String', num2str(L));

end


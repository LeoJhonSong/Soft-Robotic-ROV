function [ O1, O2, O3 ] = fDrawCurvature( theta1, phi1, r1, L, color, width, handles )
% draw curvatures
%   Detailed explanation goes here

O1 = [r1*(1-cos(theta1))*cos(phi1); - r1*(1-cos(theta1))*sin(phi1); - r1*sin(theta1); 1];
O2 = [2 * O1(1); 2 * O1(2); 2 * O1(3); 1];
O3 = [O2(1); O2(2); O2(3) - L; 1];

% segment 1
theta = 0 : theta1/20 : theta1;
x1 = r1*cos(phi1)*(1-cos(theta));
y1 = - r1*sin(phi1)*(1-cos(theta));
z1 = - r1*sin(theta);
circleHandle = plot3(handles.axes_Simu, x1, y1, z1, color);
circleHandle.LineWidth = width;

% segment 2
theta2 = theta1;
phi2 = phi1 + pi;
r2 = r1;

theta = 0 : theta2/20 : theta2;
x2 = - r2*cos(phi2)*(1-cos(theta));
y2 = r2*sin(phi2)*(1-cos(theta));
z2 = - r2*sin(theta);

x2 = 2 * O1(1) - x2;
y2 = 2 * O1(2) - y2;
z2 = 2 * O1(3) - z2;
circleHandle = plot3(handles.axes_Simu, x2, y2, z2, color);
circleHandle.LineWidth = width;

% segment 3
circleHandle = plot3(handles.axes_Simu, [O2(1) O3(1)], [O2(2) O3(2)], [O2(3) O3(3)], color);
circleHandle.LineWidth = width;

plot3(handles.axes_Simu, O1(1), O1(2), O1(3), '*g');
plot3(handles.axes_Simu, O2(1), O2(2), O2(3), '*g');

end


a=serial('COM10');
set(a,'BaudRate', 38400,'DataBits',8,'StopBits',1,'Parity','none','FlowControl','none');
 fopen(a);tt=0;
 for i=0:0.01:10
       cc = fscanf(a);
       lcc=length(cc);
%recBuff = fread(sCOM, 7, 'uint8');
       while lcc>25||cc(1)~='#'
             cc= fscanf(a) ;
             lcc=length(cc);
       end
      %fwrite(a,'clear all');
      %fclose(a);
      %recBuff = fread(sCOM, 7, 'uint8');
      ms=regexp(cc,'\-?\d*\.?\d*','match');
      DouCaX1=-str2double(ms{1});
      DouCaY1=str2double(ms{2})-10;
      DouCaZ1=str2double(ms{3})/10;
      tt=[tt,DouCaX1];
      plot(tt)
      drawnow
 end
 fclose(a)
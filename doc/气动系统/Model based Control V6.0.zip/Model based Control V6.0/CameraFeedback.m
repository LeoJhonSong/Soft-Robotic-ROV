function varargout = CameraFeedback(varargin)
% CAMERAFEEDBACK MATLAB code for CameraFeedback.fig
%      CAMERAFEEDBACK, by itself, creates a new CAMERAFEEDBACK or raises the existing
%      singleton*.
%
%      H = CAMERAFEEDBACK returns the handle to a new CAMERAFEEDBACK or the handle to
%      the existing singleton*.
%
%      CAMERAFEEDBACK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CAMERAFEEDBACK.M with the given input arguments.
%
%      CAMERAFEEDBACK('Property','Value',...) creates a new CAMERAFEEDBACK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CameraFeedback_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CameraFeedback_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CameraFeedback

% Last Modified by GUIDE v2.5 13-Jan-2018 10:18:19

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CameraFeedback_OpeningFcn, ...
                   'gui_OutputFcn',  @CameraFeedback_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CameraFeedback is made visible.
function CameraFeedback_OpeningFcn(hObject, ~, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CameraFeedback (see VARARGIN)

% Choose default command line output for CameraFeedback
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CameraFeedback wait for user response (see UIRESUME)
% uiwait(handles.CameraFeedback);
clc;
global COMCamera;  
global rate;
global OdA;
global d;
% global handleSoftArmCtrl;
COMCamera = 'COM1';%??GUI??????COM7  
rate = 115200;  
% handleSoftArmCtrl = guihandles(SerialCOM);
OdA = [0;1e-8;-338];
d = 48;
set(handles.popupmenu_CameraCOM,'value', 1);  
set(handles.popupmenu_CameraBaudRate,'value',3);


% --- Outputs from this function are returned to the command line.
function varargout = CameraFeedback_OutputFcn(~, ~, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in popupmenu_CameraCOM.
function popupmenu_CameraCOM_Callback(hObject, ~, ~)
% hObject    handle to popupmenu_CameraCOM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_CameraCOM contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_CameraCOM
global COMCamera;  
 
val = get(hObject,'value');  
switch val  
    case 1  
        COMCamera='COM1';  
%         fprintf('COM=1\n');  
    case 2  
        COMCamera='COM2';  
    case 3  
        COMCamera='COM3';  
    case 4  
        COMCamera='COM4';  
    case 5  
        COMCamera='COM5';  
    case 6  
        COMCamera='COM6';  
    case 7  
        COMCamera='COM7';  
    case 8  
        COMCamera='COM8';  
    case 9  
        COMCamera='COM9';  
    case 10  
        COMCamera='COM10';  
    case 11  
        COMCamera='COM11';  
    case 12  
        COMCamera='COM12';  
end 


% --- Executes on selection change in popupmenu_CameraBaudRate.
function popupmenu_CameraBaudRate_Callback(hObject, ~, handles)
% hObject    handle to popupmenu_CameraBaudRate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_CameraBaudRate contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_CameraBaudRate
global rate;  
val = get(hObject,'value');  
switch val  
    case 1  
        rate = 9600;  
    case 2  
        rate = 38400;
    case 3
        rate = 115200;
end 


% --- Executes on button press in pushbutton_ON.
function pushbutton_ON_Callback(~, ~, handles)
% hObject    handle to pushbutton_ON (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc  
instrreset  
global sCOMCamera;
global rate;  
global COMCamera;
sCOMCamera = serial(COMCamera);

if strcmp( get(handles.pushbutton_ON, 'string'), 'ON')    
      
    set(sCOMCamera,'BaudRate',rate);  %%% Baud rate
    set(sCOMCamera,'DataBits',8);     %%% DataBits 
    set(sCOMCamera,'StopBits',1);     %%% StopBits
    set(sCOMCamera,'InputBufferSize',102400);%%%  

    % ????????  
    sCOMCamera.BytesAvailableFcnMode='byte';                 %%% interrupt once data come
    sCOMCamera.BytesAvailableFcnCount=7;                          %%% ??????10?????????
    sCOMCamera.BytesAvailableFcn={@EveBytesAvailableFcn,handles};  %%% callback handle: EveBytesAvailableFcn
    fopen(sCOMCamera);                %%% open serial port
%     global count;  
%     count=1;  
    fprintf('Camera Serial port opened successfully\n');

    set(handles.pushbutton_ON, 'string', 'OFF');

elseif strcmp( get(handles.pushbutton_ON, 'string'), 'OFF')
    fclose(sCOMCamera);  
    delete(sCOMCamera);    
    fprintf('Camera Serial port closed successfully\n');
    set(handles.pushbutton_ON, 'string', 'ON');
end



function EveBytesAvailableFcn( ~,~,handles )  
global sCOMCamera;  
global recBuff;
global OdA;
global d;
% global handleSoftArmCtrl;
recBuff = fread(sCOMCamera, 7, 'uint8');

if length(recBuff) ~= 7
    return;
end

i = 1;
while i < 8
    if recBuff(i) == 191
        break;
    end
    i = i + 1;
end
recBuff = circshift( recBuff, -(i-1) );

if recBuff(1) ~= 191
    return;
end

DouCaX = 0; DouCaY = 0; DouCaZ = 0;
OnHandX = 0; OnHandY = 0;

% code e.g. BF 41 50 0F 18 39 80 
if (recBuff(1) == 191) && (recBuff(7) == 128)                           % start 0x1011 1111, end 0x1000 0000
    if isequal( bitget(recBuff(4), [8 7 6 5]), [0 0 0 0])               % X
        DouCaX = bitand(7, recBuff(4));
        if bitget(recBuff(4), 4) == 1
            DouCaX = -DouCaX;
        end
        set(handles.text_DouCaX, 'string', DouCaX);
    else
        DouCaX = 'error';
        set(handles.text_DouCaX, 'string', DouCaX);
    end
    
    if isequal( bitget(recBuff(5), [8 7 6 5]), [0 0 0 1])               % Y
        DouCaY = bitand(7, recBuff(5));
        if bitget(recBuff(5), 4) == 1
            DouCaY = -DouCaY;
        end
        set(handles.text_DouCaY, 'string', DouCaY);
    else
        DouCaY = 'error';
        set(handles.text_DouCaY, 'string', DouCaY);
    end
    
    if isequal( bitget(recBuff(6), [8 7 6 5]), [0 0 1 1])               % Z
        DouCaZ = bitand(7, recBuff(6));
        if bitget(recBuff(6), 4) == 1
            DouCaZ = -DouCaZ;
        end
        set(handles.text_DouCaZ, 'string', DouCaZ);
    else
        DouCaZ = 'error';
        set(handles.text_DouCaZ, 'string', DouCaZ);
    end
    
    if isequal( bitget(recBuff(2), [8 7 6 5]), [0 1 0 0])               % X
        OnHandX = bitand(7, recBuff(2));
        if bitget(recBuff(2), 4) == 1
            OnHandX = -OnHandX;
        end
        set(handles.text_OnHandX, 'string', OnHandX);
    elseif isequal( bitget(recBuff(2), [8 7 6 5]), [1 1 1 1])
        OnHandX = 'Null';
        set(handles.text_OnHandX, 'string', OnHandX);
    else
        OnHandX = 'error';
        set(handles.text_OnHandX, 'string', OnHandX);
    end
    
    if isequal( bitget(recBuff(3), [8 7 6 5]), [0 1 0 1])               % Y
        OnHandY = bitand(7, recBuff(3));
        if bitget(recBuff(3), 4) == 1
            OnHandY = -OnHandY;
        end
        set(handles.text_OnHandY, 'string', OnHandY);
    elseif isequal( bitget(recBuff(3), [8 7 6 5]), [1 1 1 1])
        OnHandY = 'Null';
        set(handles.text_OnHandY, 'string', OnHandY);
    else
        OnHandY = 'error';
        set(handles.text_OnHandY, 'string', OnHandY);
    end
end

% process redundance data
[VisionX, VisionY, VisionZ] = getCoordinate( DouCaX, DouCaY, DouCaZ, OnHandX, OnHandY );
% transfer to soft arm

if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop') &&...
        strcmp( get(handles.pushbutton_VisionAble, 'string'), 'Disable')
% if strcmp( get(handles.pushbutton_VisionAble, 'string'), 'Disable')
        
    VisionX = VisionX * 5;
    VisionY = VisionY * 5;
    VisionZ = VisionZ * 5;
    
%     fTrajectoryControl( OdA, OdA + [VisionX; VisionY; VisionZ], 'Free', 10, 's', d, handles );
    
    [ L1d(1), L1d(2), L1d(3), Ld3 ] = fInverseSimplified( OdA(1)+VisionX, OdA(2)+VisionY, OdA(3)+VisionZ, d );
    if ~fIsOverSpace( L1d(1), L1d(2), L1d(3), Ld3, handles )
        fDrivingSegments( L1d(1), L1d(2), L1d(3), Ld3, handles );
        OdA = OdA + [VisionX; VisionY; VisionZ];
        set(handles.text_ArmX, 'String', int2str(OdA(1)));
        set(handles.text_ArmY, 'String', int2str(OdA(2)));
        set(handles.text_ArmZ, 'String', int2str(OdA(3)));
    else
        warndlg('The point is OUT of workspase!','Warning');
        return;
    end
end

% if strcmp( get(handleSoftArmCtrl.pushbutton_VisionAble, 'string'), 'Disable')
%     set(handleSoftArmCtrl.text_VisionX, 'string', x);
%     set(handleSoftArmCtrl.text_VisionY, 'string', y);
%     set(handleSoftArmCtrl.text_VisionZ, 'string', z);
%     feval(@(hObject,eventdata)SerialCOM('pushbutton_ExecuteVision_Callback',0,0,handleSoftArmCtrl));
% end



function [x, y, z] = getCoordinate( DouCaX, DouCaY, DouCaZ, OnHandX, OnHandY )
rangeFar = [1 0];
rangeNear = [0 1];
if ~strcmp(DouCaX, 'error') && ~strcmp(DouCaY, 'error') && ~strcmp(DouCaZ, 'error') && ...
        ~strcmp(OnHandX, 'error') && ~strcmp(OnHandY, 'error')
    if ~strcmp(OnHandX, 'Null') && ~strcmp(OnHandY, 'Null')
        cameraSelect = rangeNear;
    else
        cameraSelect = rangeFar;
        OnHandX = 0;
        OnHandY = 0;
    end
    
    x = cameraSelect(1) * DouCaX + cameraSelect(2) * OnHandX;
    y = cameraSelect(1) * DouCaY + cameraSelect(2) * OnHandY;
    z = DouCaZ;
end



function SendBytes( String, ~ )  
global sCOMCamera; 
global sendText;
sendText = String;
sendText = [sendText, 13, 10];          %%% sendText += 0x0d 0x0a
fwrite(sCOMCamera, sendText, 'uint8');


% --- Executes during object deletion, before destroying properties.
function CameraFeedback_DeleteFcn(~, ~, ~)
% hObject    handle to CameraFeedback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global sCOMCamera;
if ~isempty(sCOMCamera) && isvalid(sCOMCamera);
    if strcmp(sCOMCamera.Status, 'open')
        fclose(sCOMCamera);         
        fprintf('Serial port closed successfully\n');
    end
    delete(sCOMCamera);
end


% --- Executes on button press in pushbutton_Start.
function pushbutton_Start_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_Start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmp( get(handles.pushbutton_ON, 'string'), 'OFF')
    if strcmp( get(handles.pushbutton_Start, 'string'), 'Start')
        SendBytes( ',', handles );
        set(handles.pushbutton_Start, 'string', 'Stop');
        set(handles.text_LED, 'backgroundcolor', 'g');
    elseif strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
        SendBytes( '.', handles );
        set(handles.pushbutton_Start, 'string', 'Start');
        set(handles.text_LED, 'backgroundcolor', 'r');
        pushbutton_Release_Callback(hObject, eventdata, handles);
    end
end


function PressureSend( pressure, channel, handles )  
% 'pressure' in string 
if channel == 1
    sendText = 'a';
elseif channel == 2
    sendText = 'b';
elseif channel == 3
    sendText = 'c';
elseif channel == 4
    sendText = 'd';
elseif channel == 5
    sendText = 'e';
elseif channel == 6
    sendText = 'f';
elseif channel == 7
    sendText = 'g';
elseif channel == 8
    sendText = 'h';
elseif channel == 9
    sendText = 'i';
elseif channel == 10
    sendText = 'j';
end

SendBytes( [sendText, pressure], handles );


function fDrivingSegments( L1, L2, L3, L, handles )
% pressure - length calibration
%%% vpa(solve(L1 == 9E-05*pressure1^3 + 0.0013*pressure1^2 +  0.1287*pressure1 + 109, pressure1))
%%% vpa(solve(L == 4.1781*(pressure4/10+1) + 83.122, pressure4))
%%% S1 == 0.98*S2 - 0.6413
%%% S2 == 7.9021*(S1/10+1) + 17.351 %%% S1 == 1.2653*S2 - 31.9575
pressure1 = (5555.5555555555555555555555555556*L1 + ((5555.5555555555555555555555555556*L1 - 602224.58212670832698267540517198)^2 + 93258097.726418903983160271113075)^(1/2) - 602224.58212670832698267540517198)^(1/3) - 453.48422496570644718792866941015/(5555.5555555555555555555555555556*L1 + ((5555.5555555555555555555555555556*L1 - 602224.58212670832698267540517198)^2 + 93258097.726418903983160271113075)^(1/2) - 602224.58212670832698267540517198)^(1/3) - 4.8148148148148148148148148148148;
pressure2 = (5555.5555555555555555555555555556*L2 + ((5555.5555555555555555555555555556*L2 - 602224.58212670832698267540517198)^2 + 93258097.726418903983160271113075)^(1/2) - 602224.58212670832698267540517198)^(1/3) - 453.48422496570644718792866941015/(5555.5555555555555555555555555556*L2 + ((5555.5555555555555555555555555556*L2 - 602224.58212670832698267540517198)^2 + 93258097.726418903983160271113075)^(1/2) - 602224.58212670832698267540517198)^(1/3) - 4.8148148148148148148148148148148;
pressure3 = (5555.5555555555555555555555555556*L3 + ((5555.5555555555555555555555555556*L3 - 602224.58212670832698267540517198)^2 + 93258097.726418903983160271113075)^(1/2) - 602224.58212670832698267540517198)^(1/3) - 453.48422496570644718792866941015/(5555.5555555555555555555555555556*L3 + ((5555.5555555555555555555555555556*L3 - 602224.58212670832698267540517198)^2 + 93258097.726418903983160271113075)^(1/2) - 602224.58212670832698267540517198)^(1/3) - 4.8148148148148148148148148148148;
pressure4 = 1.1599582415033058809882844217608*L - 139.1949889803967057185941306113;

pressure = zeros(7, 1);
%%% pressure 1
pressure(1) = ceil(0.98 * pressure1 - 0.6413);
%%% pressure 2
pressure(2) = ceil(0.98 * pressure2 - 0.6413);
%%% pressure 3
pressure(3) = ceil(0.98 * pressure3 - 0.6413);
%%% pressure 4
pressure(4) = ceil(pressure1);
%%% pressure 5
pressure(5) = ceil(pressure2);
%%% pressure 6
pressure(6) = ceil(pressure3);
%%% pressure 7 for elongation
pressure(7) = ceil(pressure4);
%%% pressure 8 for gripper
% pressure(8) = pressure5;

for i = 1 : 7
    if pressure(i) > 200
        pressure(i) = 200;
    elseif pressure(i) < 0
        pressure(i) = 0;
    end
    PressureSend(int2str(pressure(i)), i, handles ); 
%     PressureSend(int2str(pressure(i)), i, handles ); 
    pause(0.003);
end
set(handles.edit_P1, 'String', int2str(pressure(4)));
set(handles.edit_P2, 'String', int2str(pressure(5)));
set(handles.edit_P3, 'String', int2str(pressure(6)));
set(handles.edit_P4, 'String', int2str(pressure(7)));


% --- Executes on button press in pushbutton_Release.
function pushbutton_Release_Callback(~, ~, handles)
% hObject    handle to pushbutton_Release (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global OdA;
if strcmp( get(handles.pushbutton_ON, 'string'), 'OFF')    
    pressure = zeros(1, 10);
    for i = 1 : 10
        PressureSend(int2str(pressure(i)), i, handles ); 
        pause(0.003);
    end
end
OdA = [0;1e-8;-338];


% --- Executes on button press in pushbutton_VisionAble.
function pushbutton_VisionAble_Callback(~, ~, handles)
% hObject    handle to pushbutton_VisionAble (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
    if strcmp( get(handles.pushbutton_VisionAble, 'string'), 'Able')
        set(handles.pushbutton_VisionAble, 'String', 'Disable');
    elseif strcmp( get(handles.pushbutton_VisionAble, 'string'), 'Disable')
        set(handles.pushbutton_VisionAble, 'String', 'Able');    
    end
% end

function [LS,u11]=EUPI1(lambda,Pre,W1,W2,W3,xx,rr,p1,p2,t)

       u1=1*Pre+1*lambda;
       error=LS;
       for j=1:30
           xx(j,1)=max(W3(j)*u1 -rr(j), min(W2(j)*u1+rr(j), xx(j,1)));
       end
       LS=(W1*xx+p1*u1+p2*u1^3);
       LS=LS+107;
       u11=ceil(u1*51);
       %u11=LS+10*(rand(1)-0.5);
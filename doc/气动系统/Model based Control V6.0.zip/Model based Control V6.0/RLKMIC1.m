function [lambda,Q1,ier,state1,action1]=RLKMIC1(lambda,L,LS,i,Q1,RA,state1,action1,ier,alpha,gama)

       error=L-LS;s1=error;
       if isnan(s1)
           s1=0.000001;error=0.000001;
       end
       ier=ier+error*0.01;%����״̬s1
       %//////����̰������ѡ����///////////
       kexi1=0.2-0.01*i;lambda1=lambda;
       if kexi1<0.03
          kexi1=0.03;
       end
       c1=1-kexi1;
       beta1=0;
       if beta1>c1
          actionnew1=ceil(7*rand(1,1));
          if s1<-50||-isinf(s1)
             prize1=1;
          end
          if s1>=-50&&s1<-0.01
             prize1=2;
          end
          if s1>=-0.01&&s1<-0.001
             prize1=3;
          end
          if s1>=-0.001&&s1<=0.001||isnan(s1)
              prize1=4;
          end
          if s1>0.001&&s1<=0.01
             prize1=5;
          end
          if s1>0.01&&s1<=50
             prize1=6;
          end
          if s1>50||isinf(s1)
              prize1=7;
          end
      else if s1<-50||-isinf(s1)
              [a1 actionnew1]=find(Q1(1,:)==max(Q1(1,1)));
              %actionnew1=1;
               prize1=1;
          end
           if s1>=-50&&s1<-0.01
              [a1 actionnew1]=find(Q1(2,1:2)==max(Q1(2,1:2))); 
              prize1=2;
           end
           if s1>=-0.01&&s1<-0.001
              [a1 actionnew1]=find(Q1(3,2:3)==max(Q1(3,2:3)));
              actionnew1=actionnew1+1;
              prize1=3;
           end
           if s1>=-0.001&&s1<=0.001||isnan(s1)
              [a1 actionnew1]=find(Q1(4,3:5)==max(Q1(4,3:5)));
              actionnew1=actionnew1+2;
               prize1=4;
           end
           if s1>0.001&&s1<=0.01
              [a1 actionnew1]=find(Q1(5,5:6)==max(Q1(5,5:6)));
              actionnew1=actionnew1+4;
              prize1=5;
           end
           if s1>0.01&&s1<=50
              [a1 actionnew1]=find(Q1(6,6:7)==max(Q1(6,6:7)));
              actionnew1=actionnew1+5;
               prize1=6;
           end
           if s1>50||isinf(s1)
              [a1 actionnew1]=find(Q1(7,:)==max(Q1(7,7)));
              %actionnew1=7;
              prize1=7;
           end
       end
       
       %////////ֵ����������////////////
       Q1(state1,action1)=Q1(state1,action1)+alpha*(RA(prize1,action1)+gama*Q1(prize1,actionnew1(end))-Q1(state1,action1));
       Q1=Q1;
       state1=prize1;action1=actionnew1(end);
       
       %///////����ֵ��������������lambdaֵ//////////
       %%%%%%%%%%%%%%%%%%���������趨%%%%%%%%%%%%%%%%%% 
       
       if action1==1
          lambda=lambda+(0.01*s1*exp(1-50/abs(s1)))+0.01*s1+0.00*ier;
       end
       if action1==2
          lambda=lambda+(0.01*s1*sin(pi*abs(s1)/100))+0.01*s1+0.00*ier;
       end
       if action1==3
          lambda=lambda+(0.01*s1*sin(pi*abs(s1)/0.02))+0.0001*s1+0.00*ier;
       end
       if action1==4
          lambda=lambda+(0.0001*s1*sin(pi*abs(s1)/0.002))+0.00*ier;
       end
       if action1==5
          lambda=lambda+(0.01*s1*sin(pi*abs(s1)/0.02))+0.0001*s1+0.00*ier;
       end
       if action1==6
          lambda=lambda+(0.01*s1*sin(pi*abs(s1)/100))+0.01*s1+0.00*ier;
       end
       if action1==7
          lambda=lambda+0.01*s1*exp(1-50/abs(s1))+0.01*s1+0.00*ier;
       end
       lambda=lambda;
      %if isnan(lambda)
         %lambda=lambda1;
      % end
      %if lambda>2
         %lambda=2;
      %end
      %if lambda<0
          %lambda=0.001;
      %end
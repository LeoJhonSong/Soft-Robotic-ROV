%%
%VERSION 6.0
% ����tcp����

%%
% channel 1-do1
% channel 2-do2
% channel 3-do3
% channel 4.5.6-do4
% channel 7.8.9-do5
% channel 10-do6
% vaccum pump-do7
%%
function varargout = SerialCOM(varargin)
% SERIALCOM MATLAB code for SerialCOM.fig
%      SERIALCOM, by itself, creates a new SERIALCOM or raises the existing
%      singleton*.
%
%      H = SERIALCOM returns the handle to a new SERIALCOM or the handle to
%      the existing singleton*.
%
%      SERIALCOM('CALLBACK',hObject,~,handles,...) calls the local
%      function named CALLBACK in SERIALCOM.M with the given input arguments.
%
%      SERIALCOM('Property','Value',...) creates a new SERIALCOM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SerialCOM_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SerialCOM_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SerialCOM

% Last Modified by GUIDE v2.5 11-Jun-2019 10:58:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SerialCOM_OpeningFcn, ...
                   'gui_OutputFcn',  @SerialCOM_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
     gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SerialCOM is made visible.
function SerialCOM_OpeningFcn(hObject, ~, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SerialCOM (see VARARGIN)

% Choose default command line output for SerialCOM
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes SerialCOM wait for user response (see UIRESUME)
% uiwait(handles.SerialCOM);
clc;

%% tcpip do����
global dotcp;
global opendo1;
global opendo2;
global opendo3;
global opendo4;
global opendo5;
global opendo6;
global opendo7;
global opendo8;
opendo1 = uint8([ 254, 5, 0, 0, 255, 0, 152, 53] ); %FE 05 00 00 FF 00 98 35 
opendo2 = uint8([ 254, 5, 0, 1, 255, 0, 201, 245]); %FE 05 00 01 FF 00 C9 F5
opendo3 = uint8([ 254, 5, 0, 2, 255, 0, 57, 245] ); %FE 05 00 02 FF 00 39 F5
opendo4 = uint8([ 254, 5, 0, 3, 255, 0, 104, 53] ); %FE 05 00 03 FF 00 68 35
opendo5 = uint8([ 254, 5, 0, 4, 255, 0, 217, 244]); %FE 05 00 04 FF 00 D9 F4
opendo6 = uint8([ 254, 5, 0, 5, 255, 0, 136, 52] ); %FE 05 00 05 FF 00 88 34
opendo7 = uint8([ 254, 5, 0, 6, 255, 0, 120, 52] ); %FE 05 00 06 FF 00 78 34
opendo8 = uint8([ 254, 5, 0, 7, 255, 0, 41, 244] ); %FE 05 00 07 FF 00 29 F4

global closedo1;
global closedo2;
global closedo3;
global closedo4;
global closedo5;
global closedo6;
global closedo7;
global closedo8;
closedo1 = uint8([254, 5, 0, 0, 0, 0, 217, 197]); %FE 05 00 00 00 00 D9 C5
closedo2 = uint8([254, 5, 0, 1, 0, 0, 136, 5]  ); %FE 05 00 01 00 00 88 05
closedo3 = uint8([254, 5, 0, 2, 0, 0, 120, 5]  ); %FE 05 00 02 00 00 78 05
closedo4 = uint8([254, 5, 0, 3, 0, 0, 41, 197] ); %FE 05 00 03 00 00 29 C5
closedo5 = uint8([254, 5, 0, 4, 0, 0, 152, 4]  ); %FE 05 00 04 00 00 98 04
closedo6 = uint8([254, 5, 0, 5, 0, 0, 201, 196]); %FE 05 00 05 00 00 C9 C4
closedo7 = uint8([254, 5, 0, 6, 0, 0, 57, 196] ); %FE 05 00 06 00 00 39 C4
closedo8 = uint8([254, 5, 0, 7, 0, 0, 104, 4]  ); %FE 05 00 07 00 00 68 04

%% tcpip da����
global datcp;
global command;
global command_addr;
global command_registername;
global command_registeraddrH;
global command_registeraddrL;
global command_OutputNumH;
global command_OutputNumL;
global command_bytenum;
global command_DAoutput;
global command_crc16Hi;
global command_crc16Lo;
global aucCRCHi;
global aucCRCLo;
command_addr = uint8(254); %0xFE
command_registername = uint8(16); %0x10
command_registeraddrH = uint8(0); %0x00
command_registeraddrL = uint8(0); %0x00
command_OutputNumH = uint8(0); %0x00
command_OutputNumL = uint8(10);%0x0a
command_bytenum = uint8(20); %0x14
aucCRCHi = uint8([ 0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64;0;193;129;64;1;192;128;65;0;193;129;64;1;192;128;65;1;192;128;65;0;193;129;64 ]);
aucCRCLo = uint8([ 0;192;193;1;195;3;2;194;198;6;7;199;5;197;196;4;204;12;13;205;15;207;206;14;10;202;203;11;201;9;8;200;216;24;25;217;27;219;218;26;30;222;223;31;221;29;28;220;20;212;213;21;215;23;22;214;210;18;19;211;17;209;208;16;240;48;49;241;51;243;242;50;54;246;247;55;245;53;52;244;60;252;253;61;255;63;62;254;250;58;59;251;57;249;248;56;40;232;233;41;235;43;42;234;238;46;47;239;45;237;236;44;228;36;37;229;39;231;230;38;34;226;227;35;225;33;32;224;160;96;97;161;99;163;162;98;102;166;167;103;165;101;100;164;108;172;173;109;175;111;110;174;170;106;107;171;105;169;168;104;120;184;185;121;187;123;122;186;190;126;127;191;125;189;188;124;180;116;117;181;119;183;182;118;114;178;179;115;177;113;112;176;80;144;145;81;147;83;82;146;150;86;87;151;85;149;148;84;156;92;93;157;95;159;158;94;90;154;155;91;153;89;88;152;136;72;73;137;75;139;138;74;78;142;143;79;141;77;76;140;68;132;133;69;135;71;70;134;130;66;67;131;65;129;128;64]);
command = [command_addr,command_registername,command_registeraddrH,command_registeraddrL, command_bytenum,];
%% Version 5.0 
global figName;
global Od;
global OdA;
global Oadd;
global Opath;
global d;
global manualSwitch;
global stepLength;
global waterDepthPressure;
Od  = [0;1e-8;-325];
OdA = [0;1e-8;-325];
d   = 48;
figName = 1;
manualSwitch = 'S';
stepLength = str2double(get(handles.edit_ManualStep, 'String'));
waterDepthPressure = 9.886 * 1.025 * str2double(get(handles.edit_WaterDepth, 'String')) * 0.51;
Oadd = [];
Opath = [];
cla(handles.axes_Simu, 'reset');
grid on;
hold on;
axis equal;
view(60, 15)
xlabel('X(mm)');
ylabel('Y(mm)');
zlabel('Z(mm)');
rectangle('Position',[-8,-8,16,16], 'FaceColor','k');
set(handles.text_ManualX, 'String', num2str(Od(1)));
set(handles.text_ManualY, 'String', int2str(Od(2)));
set(handles.text_ManualZ, 'String', num2str(Od(3)));
% set(handles.radiobutton_ClockWise,'visible','off');
% set(handles.radiobutton_Anticlock,'visible','off');


% --- Outputs from this function are returned to the command line.
function varargout = SerialCOM_OutputFcn(~, ~, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%
% ����tcp����
% --- Executes on button press in pushbutton_ON.
function pushbutton_ON_Callback(~, ~, handles)
% hObject    handle to pushbutton_ON (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global dotcp;
global datcp;

if strcmp( get(handles.pushbutton_ON, 'string'), 'ON')    

    daip_address = get(handles.edit_daip,'string');
    daip_port = int16(str2num(get(handles.edit_daport,'string')));
    datcp = tcpip(daip_address, daip_port);
    fopen(datcp);
    doip_address = get(handles.edit_doip,'string');
    doip_port = int16(str2num(get(handles.edit_doport,'string')));
    dotcp = tcpip(doip_address, doip_port);
    fopen(dotcp);
    set(handles.pushbutton_ON, 'string', 'OFF');

elseif strcmp( get(handles.pushbutton_ON, 'string'), 'OFF')
    fclose(datcp);  
    delete(datcp);    
    fclose(dotcp);  
    delete(dotcp);
    set(handles.pushbutton_ON, 'string', 'ON');
end



% function EveBytesAvailableFcn( ~,~,handles )  
% global sCOM;  
% global recText;
% global recBuff;
% recBuff = fscanf(sCOM);%?????????? 
% recText = strcat(recText, recBuff);
% set(handles.edit_Receive, 'string', recText);


% --- Executes on button press in pushbutton_Send.
% function pushbutton_Send_Callback(~, ~, handles)
% % hObject    handle to pushbutton_Send (see GCBO)
% % ~  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% global sCOM;
% global sendText;  
% sendText = get(handles.edit_Send, 'String'); 
% fwrite(sCOM, sendText, 'uint8');


% --- Executes on button press in pushbutton_ClearSend.
% function pushbutton_ClearSend_Callback(~, ~, handles)
% % hObject    handle to pushbutton_ClearSend (see GCBO)
% % ~  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% set(handles.edit_Send, 'string', '');


% --- Executes during object deletion, before destroying properties.
function SerialCOM_DeleteFcn(~, ~, ~)
% hObject    handle to SerialCOM (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global datcp;
global dotcp;
global Oadd;
global Opath;
if ~isempty(datcp) && isvalid(datcp)
    if strcmp(datcp.Status, 'open')
        fclose(datcp);
        fclose(dotcp);
    end
    delete(datcp);
    delete(dotcp);
end
Oadd = [];
Opath = [];


% --- Executes on button press in pushbutton_ClearReceive.
% function pushbutton_ClearReceive_Callback(~, ~, handles)
% % hObject    handle to pushbutton_ClearReceive (see GCBO)
% % ~  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% set(handles.edit_Receive, 'string', '');


% % --- Executes on button press in pushbutton_Start.
% function pushbutton_Start_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton_Start (see GCBO)
% % ~  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA) 
% if strcmp( get(handles.pushbutton_ON, 'string'), 'OFF')
%     if strcmp( get(handles.pushbutton_Start, 'string'), 'Start')
%         SendBytes( ',', handles );
%         set(handles.pushbutton_Start, 'string', 'Stop');
%         set(handles.text_LED, 'backgroundcolor', 'g');
%     elseif strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
%         SendBytes( '.', handles );
%         set(handles.pushbutton_Start, 'string', 'Start');
%         set(handles.text_LED, 'backgroundcolor', 'r');
%         pushbutton_Release_Callback(hObject, eventdata, handles);
%     end
% end


% --- Executes on button press in pushbutton_PressureSet.
function pushbutton_PressureSet_Callback(~, ~, handles)
% hObject    handle to pushbutton_PressureSet (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global command;
global datcp;
global command_addr;
global command_registername;
global command_registeraddrH;
global command_registeraddrL;
global command_OutputNumH;
global command_OutputNumL;
global command_bytenum;
global command_DAoutput;
global command_crc16Hi;
global command_crc16Lo;

if strcmp(datcp.Status,'open')
    pressure  =[    uint16(2 * str2num(get(handles.edit_Ps1,'string'))),...
                    uint16(2 * str2num(get(handles.edit_Ps2,'string'))),...
                    uint16(2 * str2num(get(handles.edit_Ps3,'string'))),...
                    uint16(2 * str2num(get(handles.edit_Ps4,'string'))),...
                    uint16(2 * str2num(get(handles.edit_Ps5,'string'))),...
                    uint16(2 * str2num(get(handles.edit_Ps6,'string'))),...
                    uint16(2 * str2num(get(handles.edit_Ps7,'string'))),...
                    uint16(2 * str2num(get(handles.edit_Ps8,'string'))),...
                    uint16(2 * str2num(get(handles.edit_Ps9,'string'))),...
                    uint16(2 * str2num(get(handles.edit_Ps10,'string'))),...
                ];    
    %       pressure_hi = uint8(bitshift(pressure, -8));
    %       pressure_lo = uint8(pressure);
    command_DAoutput =  [ uint8(bitshift(pressure(1), -8)),uint8(bitand(pressure(1), 255)),...
                          uint8(bitshift(pressure(2), -8)),uint8(bitand(pressure(2), 255)),...
                          uint8(bitshift(pressure(3), -8)),uint8(bitand(pressure(3), 255)),...
                          uint8(bitshift(pressure(4), -8)),uint8(bitand(pressure(4), 255)),...
                          uint8(bitshift(pressure(5), -8)),uint8(bitand(pressure(5), 255)),...
                          uint8(bitshift(pressure(6), -8)),uint8(bitand(pressure(6), 255)),...
                          uint8(bitshift(pressure(7), -8)),uint8(bitand(pressure(7), 255)),...
                          uint8(bitshift(pressure(8), -8)),uint8(bitand(pressure(8), 255)),...
                          uint8(bitshift(pressure(9), -8)),uint8(bitand(pressure(9), 255)),...
                          uint8(bitshift(pressure(10), -8)),uint8(bitand(pressure(10), 255))
                         ] ;   
    command = [command_addr, command_registername, command_registeraddrH, ...
               command_registeraddrL, command_OutputNumH,command_OutputNumL,...
               command_bytenum,command_DAoutput(1,:)];
    calculateCRC(command);

    command = [command(1,:),command_crc16Hi,command_crc16Lo];
    fwrite(datcp,command(:,:),'char');
end




function PressureSend( pressure )  
% 'pressure' in uint16
global command;
global datcp;
global command_addr;
global command_registername;
global command_registeraddrH;
global command_registeraddrL;
global command_OutputNumH;
global command_OutputNumL;
global command_bytenum;
global command_DAoutput;
global command_crc16Hi;
global command_crc16Lo;
    %       pressure_hi = uint8(bitshift(pressure, -8));
    %       pressure_lo = uint8(pressure);
    command_DAoutput =  [ uint8(bitshift(pressure(1), -8)),uint8(bitand(pressure(1), 255)),...
                          uint8(bitshift(pressure(2), -8)),uint8(bitand(pressure(2), 255)),...
                          uint8(bitshift(pressure(3), -8)),uint8(bitand(pressure(3), 255)),...
                          uint8(bitshift(pressure(4), -8)),uint8(bitand(pressure(4), 255)),...
                          uint8(bitshift(pressure(5), -8)),uint8(bitand(pressure(5), 255)),...
                          uint8(bitshift(pressure(6), -8)),uint8(bitand(pressure(6), 255)),...
                          uint8(bitshift(pressure(7), -8)),uint8(bitand(pressure(7), 255)),...
                          uint8(bitshift(pressure(8), -8)),uint8(bitand(pressure(8), 255)),...
                          uint8(bitshift(pressure(9), -8)),uint8(bitand(pressure(9), 255)),...
                          uint8(bitshift(pressure(10), -8)),uint8(bitand(pressure(10), 255)) ] ;  

    command = [command_addr, command_registername, command_registeraddrH, ...
               command_registeraddrL, command_OutputNumH,command_OutputNumL,...
               command_bytenum,command_DAoutput(1,:)];
    calculateCRC(command);

    command = [command(1,:),command_crc16Hi,command_crc16Lo];
    fwrite(datcp,command(:,:),'char');




% --- Executes on button press in pushbutton_Release.
function pushbutton_Release_Callback(~, ~, handles)
% hObject    handle to pushbutton_Release (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Od;
global OdA;
if strcmp( get(handles.pushbutton_ON, 'string'), 'OFF')    
    pressure = uint16(zeros(1, 10));
    PressureSend(pressure); 
end
set(handles.edit_Ps1, 'String', '0');
set(handles.edit_Ps2, 'String', '0');
set(handles.edit_Ps3, 'String', '0');
set(handles.edit_Ps4, 'String', '0');
set(handles.edit_Ps5, 'String', '0');
set(handles.edit_Ps6, 'String', '0');
set(handles.edit_Ps7, 'String', '0');
set(handles.edit_Ps8, 'String', '0');
set(handles.edit_Ps9, 'String', '0');
set(handles.edit_Ps10, 'String', '0');
Od  = [0;1e-8;-325];
OdA = [0;1e-8;-325];
set(handles.text_ManualX, 'String', num2str(Od(1)));
set(handles.text_ManualY, 'String', int2str(Od(2)));
set(handles.text_ManualZ, 'String', num2str(Od(3)));



% --- Executes on button press in radiobutton_Linear.
function radiobutton_Linear_Callback(~, ~, handles)
% hObject    handle to radiobutton_Linear (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_Linear
set(handles.radiobutton_Linear,'value',1);
set(handles.radiobutton_Free,'value',0);
set(handles.radiobutton_ClockWise,'value',0);
set(handles.radiobutton_Anticlock,'value',0);
set(handles.radiobutton_8shape,'value',0);


% --- Executes on button press in radiobutton_Free.
function radiobutton_Free_Callback(~, ~, handles)
% hObject    handle to radiobutton_Free (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_Free
set(handles.radiobutton_Linear,'value',0);
set(handles.radiobutton_Free,'value',1);
set(handles.radiobutton_ClockWise,'value',0);
set(handles.radiobutton_Anticlock,'value',0);
set(handles.radiobutton_8shape,'value',0);


% --- Executes on button press in radiobutton_ClockWise.
function radiobutton_ClockWise_Callback(~, ~, handles)
% hObject    handle to radiobutton_ClockWise (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_ClockWise
set(handles.radiobutton_Linear,'value',0);
set(handles.radiobutton_Free,'value',0);
set(handles.radiobutton_ClockWise,'value',1);
set(handles.radiobutton_Anticlock,'value',0);
set(handles.radiobutton_8shape,'value',0);


% --- Executes on button press in radiobutton_Anticlock.
function radiobutton_Anticlock_Callback(~, ~, handles)
% hObject    handle to radiobutton_Anticlock (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_Anticlock
set(handles.radiobutton_Linear,'value',0);
set(handles.radiobutton_Free,'value',0);
set(handles.radiobutton_ClockWise,'value',0);
set(handles.radiobutton_Anticlock,'value',1);
set(handles.radiobutton_8shape,'value',0);


% --- Executes on button press in radiobutton_8shape.
function radiobutton_8shape_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_8shape (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_8shape
set(handles.radiobutton_Linear,'value',0);
set(handles.radiobutton_Free,'value',0);
set(handles.radiobutton_ClockWise,'value',0);
set(handles.radiobutton_Anticlock,'value',0);
set(handles.radiobutton_8shape,'value',1);


% Trajectory Control of the underwater soft arm in opposing curvature
%   Included trajectories: Line, Circle in clockwise and anticlockwise, "8" shape.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameters:
%   Oi,     initial point coordinate, e.g. [0;1e-8;-325]
%   Od,     final point coordinate
%   Mode,   trajectory shape: "Line", "Circle", "8"
%   Speed,  moving speed, e.g. 0mm/s
%   Act,    "s" for simulation, "a" for actuation.
%   d,      radius of soft arm, mm.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [  ] = fTrajectoryControl( Oi, Od, Mode, Speed, Act, d, handles )
% initial location parameters
[ L1i(1), L1i(2), L1i(3), Li3 ] = fInverseSimplified( Oi(1), Oi(2), Oi(3), d );
% draw curvatures
if ~fIsOverSpace( L1i(1), L1i(2), L1i(3), Li3, handles )
    [ theta, phi, r ] = fSpecific( L1i(1), L1i(2), L1i(3), d );
    if strcmp( Act, 'a')
       fDrivingSegments( L1i(1), L1i(2), L1i(3), Li3, handles ); 
    end
    fDrawCurvature( theta, phi, r, Li3, '-r', 2, handles );
else
    warndlg('Initial point is OUT of workspase!','Warning');
    return;
end

% distination parameters
[ L1d(1), L1d(2), L1d(3), Ld3 ] = fInverseSimplified( Od(1), Od(2), Od(3), d );
% draw curvatures
if ~fIsOverSpace( L1d(1), L1d(2), L1d(3), Ld3, handles )
    [ theta, phi, r ] = fSpecific( L1d(1), L1d(2), L1d(3), d );
    fDrawCurvature( theta, phi, r, Ld3, '-r', 2, handles );
else
    warndlg('Final point is OUT of workspase!','Warning');
    return;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Line trajectory
if strcmp( Mode, 'Line')
    % step calculation: coordinate-based moving
    pathLength = sqrt(((Oi(1)-Od(1))^2 + (Oi(2)-Od(2))^2 + (Oi(3)-Od(3))^2));
    stepLength = Speed / 5;
    step = ceil(pathLength / stepLength);
    stepX = (Od(1) - Oi(1)) / step;
    stepY = (Od(2) - Oi(2)) / step;
    stepZ = (Od(3) - Oi(3)) / step;
    Om = Oi;

    for i = 1 : 1 : step
        % step increament
        %%% speed control    
        Om = Om + [stepX; stepY; stepZ];

        [ L1m(1), L1m(2), L1m(3), Lm3 ] = fInverseSimplified( Om(1), Om(2), Om(3), d );

        % draw curvatures
        if ~fIsOverSpace( L1m(1), L1m(2), L1m(3), Lm3, handles )
            if strcmp( Act, 'a')
               fDrivingSegments( L1m(1), L1m(2), L1m(3), Lm3, handles );
            elseif strcmp( Act, 's') && mod(i, 5)==0
               [ theta, phi, r ] = fSpecific( L1m(1), L1m(2), L1m(3), d );
               fDrawCurvature( theta, phi, r, Lm3, '-b', 1, handles );
            end          
            pause(0.2);
        else
            warndlg('The point is OUT of workspase!','Warning');
            return;
        end
    end
    
% Circle trajectory    
elseif strcmp( Mode, 'Clockwise') || strcmp( Mode, 'Anticlock')
    % step calculation: coordinate-based moving
    radius = 0.5 * sqrt(((Oi(1)-Od(1))^2 + (Oi(2)-Od(2))^2 + (Oi(3)-Od(3))^2)); % radius of circle
    Oc = 0.5 * ( Od + Oi );                         % circle center
    alpha = atan2(Od(2) - Oi(2), Od(1) - Oi(1));    % angle of Line{Od, Oi}s
    pathLength = pi * radius;
    stepLength = Speed / 5;
    stepAngle = stepLength / radius;
    step = ceil(pathLength / stepLength);
    Beta = alpha - pi;                              % central angle
    stepZ = (Od(3) - Oi(3)) / step;
    Om = Oi;

    for i = 1 : 1 : step-1
        % step increament
        %%% speed control
        Om = [radius * cos(Beta) + Oc(1);...
              radius * sin(Beta) + Oc(2);...
              Om(3) + stepZ];

        [ L1m(1), L1m(2), L1m(3), Lm3 ] = fInverseSimplified( Om(1), Om(2), Om(3), d );

        % draw curvatures
        if ~fIsOverSpace( L1m(1), L1m(2), L1m(3), Lm3, handles )
            if strcmp( Act, 'a')
               fDrivingSegments( L1m(1), L1m(2), L1m(3), Lm3, handles );
            elseif strcmp( Act, 's') && mod(i, 5)==0
               [ theta, phi, r ] = fSpecific( L1m(1), L1m(2), L1m(3), d );
               fDrawCurvature( theta, phi, r, Lm3, '-b', 1, handles );
            end          
            pause(0.2);
        else
            warndlg('The point is OUT of workspase!','Warning');
            return;
        end
        
        if strcmp( Mode, 'Clockwise')
            Beta = Beta + stepAngle;
        elseif strcmp( Mode, 'Anticlock')
            Beta = Beta - stepAngle;
        end
    end
    Om = Od;
    [ L1m(1), L1m(2), L1m(3), Lm3 ] = fInverseSimplified( Om(1), Om(2), Om(3), d );
    % draw curvatures
    if ~fIsOverSpace( L1m(1), L1m(2), L1m(3), Lm3, handles )
        if strcmp( Act, 'a')
           fDrivingSegments( L1m(1), L1m(2), L1m(3), Lm3, handles );
        elseif strcmp( Act, 's')
           [ theta, phi, r ] = fSpecific( L1m(1), L1m(2), L1m(3), d );
           fDrawCurvature( theta, phi, r, Lm3, '-b', 1, handles );
        end
    else
        warndlg('The final point is OUT of workspase!','Warning');
        return;
    end 
    
% "8" shape trajectory    
elseif strcmp( Mode, '8')
    % step calculation: coordinate-based moving
    radius = 0.5 * sqrt(((Oi(1)-Od(1))^2 + (Oi(2)-Od(2))^2 + (Oi(3)-Od(3))^2)); % radius of circle
    alpha = atan2(Od(2) - Oi(2), Od(1) - Oi(1));    % angle of Line{Od, Oi}s
    pathLength = 2 * pi * radius;
    stepLength = Speed / 5;
    stepAngle = stepLength / radius;
    step = ceil(pathLength / stepLength);
    beta = alpha + pi;                              % central angle
    
    Om = (Oi+Od)/2;
    [ L1m(1), L1m(2), L1m(3), Lm3 ] = fInverseSimplified( Om(1), Om(2), Om(3), d );
    % draw curvatures
    if ~fIsOverSpace( L1m(1), L1m(2), L1m(3), Lm3, handles )
        if strcmp( Act, 'a')
           fDrivingSegments( L1m(1), L1m(2), L1m(3), Lm3, handles );
        elseif strcmp( Act, 's')
           [ theta, phi, r ] = fSpecific( L1m(1), L1m(2), L1m(3), d );
           fDrawCurvature( theta, phi, r, Lm3, '-b', 1, handles );
        end
    else
        warndlg('The final point is OUT of workspase!','Warning');
        return;
    end 

    for i = 1 : 1 : step-1
        % step increament
        %%% speed control
        Om = [radius * cos(alpha) + Oi(1);...
              radius * sin(alpha) + Oi(2);...
              (Od(3) + Oi(3))/2 - (Od(3) - Oi(3))/2 * (1 - cos(i*stepAngle))];

        [ L1m(1), L1m(2), L1m(3), Lm3 ] = fInverseSimplified( Om(1), Om(2), Om(3), d );

        % draw curvatures
        if ~fIsOverSpace( L1m(1), L1m(2), L1m(3), Lm3, handles )
            if strcmp( Act, 'a')
               fDrivingSegments( L1m(1), L1m(2), L1m(3), Lm3, handles );
            elseif strcmp( Act, 's') && mod(i, 5)==0
               [ theta, phi, r ] = fSpecific( L1m(1), L1m(2), L1m(3), d );
               fDrawCurvature( theta, phi, r, Lm3, '-b', 1, handles );
            end          
            pause(0.2);
        else
            warndlg('The point is OUT of workspase!','Warning');
            return;
        end
        
        alpha = alpha - stepAngle;
    end
    
    for i = 1 : 1 : step-1
        % step increament
        %%% speed control
        Om = [radius * cos(beta) + Od(1);...
              radius * sin(beta) + Od(2);...
              (Od(3) + Oi(3))/2 + (Od(3) - Oi(3))/2 * (1 - cos(i*stepAngle))];

        [ L1m(1), L1m(2), L1m(3), Lm3 ] = fInverseSimplified( Om(1), Om(2), Om(3), d );

        % draw curvatures
        if ~fIsOverSpace( L1m(1), L1m(2), L1m(3), Lm3, handles )
            [ theta, phi, r ] = fSpecific( L1m(1), L1m(2), L1m(3), d );
            if strcmp( Act, 'a')
               fDrivingSegments( L1m(1), L1m(2), L1m(3), Lm3, handles );
            elseif strcmp( Act, 's') && mod(i, 5)==0
               fDrawCurvature( theta, phi, r, Lm3, '-b', 1, handles );
            end          
            pause(0.2);
        else
            warndlg('The point is OUT of workspase!','Warning');
            return;
        end
        
        beta = beta + stepAngle;

    end
    
    Om = (Oi+Od)/2;
    [ L1m(1), L1m(2), L1m(3), Lm3 ] = fInverseSimplified( Om(1), Om(2), Om(3), d );
    % draw curvatures
    if ~fIsOverSpace( L1m(1), L1m(2), L1m(3), Lm3, handles )
        if strcmp( Act, 'a')
           fDrivingSegments( L1m(1), L1m(2), L1m(3), Lm3, handles );
        elseif strcmp( Act, 's')
           [ theta, phi, r ] = fSpecific( L1m(1), L1m(2), L1m(3), d );
           fDrawCurvature( theta, phi, r, Lm3, '-b', 1, handles );
        end
    else
        warndlg('The final point is OUT of workspase!','Warning');
        return;
    end 
    
% Free trajectory
elseif strcmp( Mode, 'Free')
    if strcmp( Act, 'a')
       % actuation
        if ~fIsOverSpace( L1d(1), L1d(2), L1d(3), Ld3, handles )
            fDrivingSegments( L1d(1), L1d(2), L1d(3), Ld3, handles );
        else
            warndlg('The point is OUT of workspase!','Warning');
            return;
        end
    elseif strcmp( Act, 's')
        % step calculation: length-based moving
        [step, maxIndex] = max([abs(L1d(1)-L1i(1)) abs(L1d(2)-L1i(2)) abs(L1d(3)-L1i(3))]);        % max and index
        stepLength = 5;
        step = ceil(step / stepLength);                                             % bigger int
        index = [1 2 3];
        index(maxIndex) = [];                                                       % remove the maxIndex
        L1m = [L1i(1), L1i(2), L1i(3)]; Lm3 = Li3;

        for i = 1 : 1 : step-1
            % step increament
            %%% speed control
            L1m(maxIndex) = L1m(maxIndex) + sign(L1d(maxIndex)-L1i(maxIndex)) * stepLength;
            L1m(index(1)) = L1m(index(1)) + (L1d(index(1))-L1i(index(1))) / step;
            L1m(index(2)) = L1m(index(2)) + (L1d(index(2))-L1i(index(2))) / step;
            Lm3 = Lm3 + (Ld3 - Li3) / step;

            % draw curvatures
            if ~fIsOverSpace( L1m(1), L1m(2), L1m(3), Lm3, handles )
                [ theta1, phi1, r1 ] = fSpecific( L1m(1), L1m(2), L1m(3), d );
                fDrawCurvature( theta1, phi1, r1, Lm3, '-b', 1, handles );
            else
                warndlg('The point is OUT of workspase!','Warning');
                return;
            end        

            pause(0.2);
        end

        L1m(maxIndex) = L1d(maxIndex);
        L1m(index(1)) = L1d(index(1));
        L1m(index(2)) = L1d(index(2));
        Lm3 = Ld3;

        % draw curvatures
        if ~fIsOverSpace( L1m(1), L1m(2), L1m(3), Lm3, handles )
            [ theta1, phi1, r1 ] = fSpecific( L1m(1), L1m(2), L1m(3), d );
            fDrawCurvature( theta1, phi1, r1, Lm3, '-b', 1, handles );
        else
            warndlg('The final point is OUT of workspase!','Warning');
            return;
        end
    end   
    
end


% --- Executes on button press in pushbutton_Simulation.
function pushbutton_Simulation_Callback(~, ~, handles)
% hObject    handle to pushbutton_Simulation (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Od;
global d;
global Oadd;
global Opath;
cla(handles.axes_Simu, 'reset');
grid on;
hold on;
axis equal;
view(60, 15)
xlabel('X(mm)');
ylabel('Y(mm)');
zlabel('Z(mm)');
rectangle('Position',[-8,-8,16,16], 'FaceColor','k');

% from
if ~isempty(get(handles.edit_FrX, 'String'))
    Oi = [str2double(get(handles.edit_FrX, 'String'));...
          str2double(get(handles.edit_FrY, 'String'));...
          str2double(get(handles.edit_FrZ, 'String'))];
else
    Oi = [Od(1); Od(2); Od(3)];
end

if isempty(Oadd)
    % to
    Od = [str2double(get(handles.edit_ToX, 'String'));...
          str2double(get(handles.edit_ToY, 'String'));...
          str2double(get(handles.edit_ToZ, 'String'))];

    % Speed
    Speed = str2double(get(handles.edit_Speed, 'String'));

    % linear path tracking
    if get(handles.radiobutton_Linear,'value')
        fTrajectoryControl( Oi, Od, 'Line', Speed, 's', d, handles );

    % circle path tracking
    elseif get(handles.radiobutton_ClockWise,'value')
        fTrajectoryControl( Oi, Od, 'Clockwise', Speed, 's', d, handles );
    elseif get(handles.radiobutton_Anticlock,'value') 
        fTrajectoryControl( Oi, Od, 'Anticlock', Speed, 's', d, handles );

    % Free path tracking
    elseif get(handles.radiobutton_Free,'value')
        fTrajectoryControl( Oi, Od, 'Free', Speed, 's', d, handles );

    % "8" shape path tracking
    elseif get(handles.radiobutton_8shape,'value')
        fTrajectoryControl( Oi, Od, '8', Speed, 's', d, handles );
    end
    
else
    if Oadd(1:3,1)~= Oi
        Oadd = [[Oi;0] Oadd];
        Opath = [{'Free'}, Opath];
    end
    [~,PathNumber] = size(Oadd);
    i = 1;
    while i < PathNumber
        fTrajectoryControl( Oadd(1:3,i), Oadd(1:3,i+1), Opath{i+1}, Oadd(4,i+1), 's', d, handles );
        i = i + 1;
    end
end



% --- Executes on button press in pushbutton_Actuation.
function pushbutton_Actuation_Callback(~, ~, handles)
% hObject    handle to pushbutton_Actuation (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global OdA;
global d;
global Oadd;
global Opath;
% if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')    
    if ~isempty(get(handles.edit_FrX, 'String'))
        % from
        Oi = [str2double(get(handles.edit_FrX, 'String'));...
              str2double(get(handles.edit_FrY, 'String'));...
              str2double(get(handles.edit_FrZ, 'String'))];        
    else
        Oi = [OdA(1); OdA(2); OdA(3)];
    end
    
    if isempty(Oadd)
        % to
        OdA = [str2double(get(handles.edit_ToX, 'String'));...
               str2double(get(handles.edit_ToY, 'String'));...
               str2double(get(handles.edit_ToZ, 'String'))];

        % speed
        Speed = str2double(get(handles.edit_Speed, 'String'));

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % linear path tracking
        if get(handles.radiobutton_Linear,'value')
            fTrajectoryControl( Oi, OdA, 'Line', Speed, 'a', d, handles );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % circle path tracking
        elseif get(handles.radiobutton_ClockWise,'value')
            fTrajectoryControl( Oi, OdA, 'Clockwise', Speed, 'a', d, handles );
        elseif get(handles.radiobutton_Anticlock,'value') 
            fTrajectoryControl( Oi, OdA, 'Anticlock', Speed, 'a', d, handles );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Free path tracking
        elseif get(handles.radiobutton_Free,'value')
            fTrajectoryControl( Oi, OdA, 'Free', Speed, 'a', d, handles );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % "8" shape path tracking
        elseif get(handles.radiobutton_8shape,'value')
            fTrajectoryControl( Oi, OdA, '8', Speed, 'a', d, handles );
        end
        
    else
        if Oadd(1:3,1)~= Oi
            Oadd = [[Oi;0] Oadd];
            Opath = [{'Free'}, Opath];
        end
        [~,PathNumber] = size(Oadd);
        i = 1;
        while i < PathNumber
            fTrajectoryControl( Oadd(1:3,i), Oadd(1:3,i+1), Opath{i+1}, Oadd(4,i+1), 'a', d, handles );
            i = i + 1;
            pause(1);
        end
    end
% end


% --- Executes on button press in pushbutton_AddPath.
function pushbutton_AddPath_Callback(~, ~, handles)
% hObject    handle to pushbutton_AddPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Oadd;
global Opath;
Oadd = [Oadd ...
        [str2double(get(handles.edit_ToX, 'String'));...
         str2double(get(handles.edit_ToY, 'String'));...
         str2double(get(handles.edit_ToZ, 'String'));...
         str2double(get(handles.edit_Speed, 'String'))]];

% linear path tracking
if get(handles.radiobutton_Linear,'value')
    Opath = [Opath, {'Line'}];
% circle path tracking
elseif get(handles.radiobutton_ClockWise,'value')
    Opath = [Opath, {'Clockwise'}];
elseif get(handles.radiobutton_Anticlock,'value') 
    Opath = [Opath, {'Anticlock'}];
% Free path tracking
elseif get(handles.radiobutton_Free,'value')
    Opath = [Opath, {'Free'}];
% "8" shape path tracking
elseif get(handles.radiobutton_8shape,'value')
    Opath = [Opath, {'8'}];
end

[~,PathNumber] = size(Oadd);
set(handles.pushbutton_AddPath, 'String', ['Add Path (', int2str(PathNumber), ')']);



% right click
% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over pushbutton_AddPath.
function pushbutton_AddPath_ButtonDownFcn(~, ~, handles)
% hObject    handle to pushbutton_AddPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Oadd;
global Opath;
if strcmp( get(gcbf,'SelectionType'), 'alt' )
    [~,PathNumber] = size(Oadd);
    if PathNumber >0
        Oadd(:,end) = [];
        Opath(:,end) = [];
        set(handles.pushbutton_AddPath, 'String', ['Add Path (', int2str(PathNumber-1), ')']);
    end
elseif strcmp( get(gcbf,'SelectionType'), 'open' )
     Oadd = [];
     Opath = [];
     set(handles.pushbutton_AddPath, 'String', ['Add Path (0)']);
end



function fDrivingSegments( L1, L2, L3, L, handles )
global waterDepthPressure;
% pressure - length calibration
%%% vpa(solve(L1 == 9E-05*pressure1^3 + 0.0013*pressure1^2 +  0.1287*pressure1 + 109, pressure1))
%%% vpa(solve(L == 4.1781*(pressure4/10+1) + 83.122, pressure4))
%%% S1 == 0.98*S2 - 0.6413
%%% S2 == 7.9021*(S1/10+1) + 17.351 %%% S1 == 1.2653*S2 - 31.9575
pressure1 = (5555.5555555555555555555555555556*L1 + ((5555.5555555555555555555555555556*L1 - 602224.58212670832698267540517198)^2 + 93258097.726418903983160271113075)^(1/2) - 602224.58212670832698267540517198)^(1/3) - 453.48422496570644718792866941015/(5555.5555555555555555555555555556*L1 + ((5555.5555555555555555555555555556*L1 - 602224.58212670832698267540517198)^2 + 93258097.726418903983160271113075)^(1/2) - 602224.58212670832698267540517198)^(1/3) - 4.8148148148148148148148148148148;
pressure2 = (5555.5555555555555555555555555556*L2 + ((5555.5555555555555555555555555556*L2 - 602224.58212670832698267540517198)^2 + 93258097.726418903983160271113075)^(1/2) - 602224.58212670832698267540517198)^(1/3) - 453.48422496570644718792866941015/(5555.5555555555555555555555555556*L2 + ((5555.5555555555555555555555555556*L2 - 602224.58212670832698267540517198)^2 + 93258097.726418903983160271113075)^(1/2) - 602224.58212670832698267540517198)^(1/3) - 4.8148148148148148148148148148148;
pressure3 = (5555.5555555555555555555555555556*L3 + ((5555.5555555555555555555555555556*L3 - 602224.58212670832698267540517198)^2 + 93258097.726418903983160271113075)^(1/2) - 602224.58212670832698267540517198)^(1/3) - 453.48422496570644718792866941015/(5555.5555555555555555555555555556*L3 + ((5555.5555555555555555555555555556*L3 - 602224.58212670832698267540517198)^2 + 93258097.726418903983160271113075)^(1/2) - 602224.58212670832698267540517198)^(1/3) - 4.8148148148148148148148148148148;
pressure4 = 0.51789321*L - 54.4050672;

pressure = zeros(10, 1);
%%% pressure 1
pressure(1) = uint16(pressure1*2);
%%% pressure 2
pressure(2) = uint16(pressure2*2);
%%% pressure 3
pressure(3) = uint16(pressure3*2);
%%% pressure 4
pressure(4) = uint16(pressure1*2);
%%% pressure 5
pressure(5) = uint16(pressure2*2);
%%% pressure 6
pressure(6) = uint16(pressure3*2);
%%% pressure 7 for elongation
pressure(7) = uint16(pressure4*2);
%%% pressure 8 for gripper
pressure(8) = uint16(0);
pressure(9) = uint16(0);
pressure(10) = uint16(0);

for i = 1 : 7
    pressure(i) = pressure(i) + waterDepthPressure;
end

PressureSend( pressure );
set(handles.edit_P1, 'String', int2str(pressure(4)));
set(handles.edit_P2, 'String', int2str(pressure(5)));
set(handles.edit_P3, 'String', int2str(pressure(6)));
set(handles.edit_P4, 'String', int2str(pressure(7)));



% --- Executes on button press in pushbutton_SaveFig.
function pushbutton_SaveFig_Callback(hObject, ~, handles)
% hObject    handle to pushbutton_SaveFig (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global figName;
fig=get(handles.axes_Simu,'children');
figure('visible','off');
grid on;
axis equal;
xlabel('X(mm)');
ylabel('Y(mm)');
zlabel('Z(mm)');
view(60, 15);
copyobj(fig,gca);
saveas(gca, num2str(figName), 'jpeg')
figName = figName + 1;


% --- Executes on button press in pushbutton_XH.
function pushbutton_XH_Callback(hObject, ~, handles)
% hObject    handle to pushbutton_XH (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ManualControl('X+', handles);


% --- Executes on button press in pushbutton_XL.
function pushbutton_XL_Callback(hObject, ~, handles)
% hObject    handle to pushbutton_XL (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ManualControl('X-', handles);


% --- Executes on button press in pushbutton_YH.
function pushbutton_YH_Callback(hObject, ~, handles)
% hObject    handle to pushbutton_YH (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ManualControl('Y+', handles);


% --- Executes on button press in pushbutton_YL.
function pushbutton_YL_Callback(hObject, ~, handles)
% hObject    handle to pushbutton_YL (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ManualControl('Y-', handles);


% --- Executes on button press in pushbutton_ZH.
function pushbutton_ZH_Callback(hObject, ~, handles)
% hObject    handle to pushbutton_ZH (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ManualControl('Z+', handles);


% --- Executes on button press in pushbutton_ZL.
function pushbutton_ZL_Callback(hObject, ~, handles)
% hObject    handle to pushbutton_ZL (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ManualControl('Z-', handles);



function ManualControl(direction, handles)
global Od;
global OdA;
global d;
global manualSwitch;
global stepLength;
cla(handles.axes_Simu, 'reset');
grid on;
hold on;
axis equal;
view(60, 15)
xlabel('X(mm)');
ylabel('Y(mm)');
zlabel('Z(mm)');
rectangle('Position',[-8,-8,16,16], 'FaceColor','k');

switch manualSwitch
    case 'A'          % Actuation
%         if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
            % from
            Oi = OdA;
            % initial location parameters
            [ L1i(1), L1i(2), L1i(3), Li3 ] = fInverseSimplified( Oi(1), Oi(2), Oi(3), d );
            % draw curvatures
            if ~fIsOverSpace( L1i(1), L1i(2), L1i(3), Li3, handles )
                [ theta, phi, r ] = fSpecific( L1i(1), L1i(2), L1i(3), d );
                fDrawCurvature( theta, phi, r, Li3, '--b', 1, handles );
            else
                warndlg('Initial point is OUT of workspase!','Warning');
                return;
            end

            % to
            if     strcmp(direction, 'X+')
                OdA = [Oi(1) + stepLength; Oi(2); Oi(3)];
            elseif strcmp(direction, 'X-')
                OdA = [Oi(1) - stepLength; Oi(2); Oi(3)];
            elseif strcmp(direction, 'Y+')
                OdA = [Oi(1); Oi(2) + stepLength; Oi(3)];
            elseif strcmp(direction, 'Y-')
                OdA = [Oi(1); Oi(2) - stepLength; Oi(3)];
            elseif strcmp(direction, 'Z+')
                OdA = [Oi(1); Oi(2); Oi(3) + stepLength];
            elseif strcmp(direction, 'Z-')
                OdA = [Oi(1); Oi(2); Oi(3) - stepLength];
            end

            % distination parameters
            [ L1d(1), L1d(2), L1d(3), Ld3 ] = fInverseSimplified( OdA(1), OdA(2), OdA(3), d );
            % draw curvatures
            if ~fIsOverSpace( L1d(1), L1d(2), L1d(3), Ld3, handles )
                fDrivingSegments( L1d(1), L1d(2), L1d(3), Ld3, handles );
                [ theta, phi, r ] = fSpecific( L1d(1), L1d(2), L1d(3), d );
                fDrawCurvature( theta, phi, r, Ld3, '-r', 2, handles );
                set(handles.text_ManualX, 'String', num2str(OdA(1)));
                set(handles.text_ManualY, 'String', num2str(OdA(2)));
                set(handles.text_ManualZ, 'String', num2str(OdA(3)));
            else
                warndlg('Final point is OUT of workspase!','Warning');
                OdA = Oi;
                return;
            end
%         end
        
    case 'S'          % Simulation
        % from
        Oi = Od;
        % initial location parameters
        [ L1i(1), L1i(2), L1i(3), Li3 ] = fInverseSimplified( Oi(1), Oi(2), Oi(3), d );
        % draw curvatures
        if ~fIsOverSpace( L1i(1), L1i(2), L1i(3), Li3, handles )
            [ theta, phi, r ] = fSpecific( L1i(1), L1i(2), L1i(3), d );
            fDrawCurvature( theta, phi, r, Li3, '--b', 1, handles );
        else
            warndlg('Initial point is OUT of workspase!','Warning');
            return;
        end

        % to
        if     strcmp(direction, 'X+')
            Od = [Oi(1) + stepLength; Oi(2); Oi(3)];
        elseif strcmp(direction, 'X-')
            Od = [Oi(1) - stepLength; Oi(2); Oi(3)];
        elseif strcmp(direction, 'Y+')
            Od = [Oi(1); Oi(2) + stepLength; Oi(3)];
        elseif strcmp(direction, 'Y-')
            Od = [Oi(1); Oi(2) - stepLength; Oi(3)];
        elseif strcmp(direction, 'Z+')
            Od = [Oi(1); Oi(2); Oi(3) + stepLength];
        elseif strcmp(direction, 'Z-')
            Od = [Oi(1); Oi(2); Oi(3) - stepLength];
        end

        % distination parameters
        [ L1d(1), L1d(2), L1d(3), Ld3 ] = fInverseSimplified( Od(1), Od(2), Od(3), d );
        % draw curvatures
        if ~fIsOverSpace( L1d(1), L1d(2), L1d(3), Ld3, handles )
            [ theta, phi, r ] = fSpecific( L1d(1), L1d(2), L1d(3), d );
            fDrawCurvature( theta, phi, r, Ld3, '-r', 2, handles );
            set(handles.text_ManualX, 'String', num2str(Od(1)));
            set(handles.text_ManualY, 'String', num2str(Od(2)));
            set(handles.text_ManualZ, 'String', num2str(Od(3)));
        else
            warndlg('Final point is OUT of workspase!','Warning');
            Od = Oi;
            return;
        end
end



% --- Executes on selection change in popupmenu_Switch.
function popupmenu_Switch_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_Switch (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_Switch contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_Switch
global manualSwitch;  
global Od;
global OdA;
global d;
val = get(hObject,'value');  
switch val  
    case 1  
        manualSwitch = 'S';
        % initial location parameters
        [ L1i(1), L1i(2), L1i(3), Li3 ] = fInverseSimplified( Od(1), Od(2), Od(3), d );
        % draw curvatures
        if ~fIsOverSpace( L1i(1), L1i(2), L1i(3), Li3, handles )
            [ theta, phi, r ] = fSpecific( L1i(1), L1i(2), L1i(3), d );
            fDrawCurvature( theta, phi, r, Li3, '-r', 2, handles );
        else
            warndlg('Initial point is OUT of workspase!','Warning');
            return;
        end

    case 2  
        manualSwitch = 'A';
        % initial location parameters
        [ L1i(1), L1i(2), L1i(3), Li3 ] = fInverseSimplified( OdA(1), OdA(2), OdA(3), d );
        % draw curvatures
        if ~fIsOverSpace( L1i(1), L1i(2), L1i(3), Li3, handles )
            [ theta, phi, r ] = fSpecific( L1i(1), L1i(2), L1i(3), d );
            fDrawCurvature( theta, phi, r, Li3, '-r', 2, handles );
        else
            warndlg('Initial point is OUT of workspase!','Warning');
            return;
        end
end 


% --- Executes on key press with focus on checkbox_KeyboardCtrl and none of its controls.
function checkbox_KeyboardCtrl_KeyPressFcn(hObject, ~, handles)
% hObject    handle to checkbox_KeyboardCtrl (see GCBO)
% ~  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
global stepLength;
if(get(hObject,'Value'))
    if      get(gcf,'CurrentCharacter') == 100      % 'd', X+
        ManualControl('X+', handles);
    elseif  get(gcf,'CurrentCharacter') == 97       % 'a', X-
        ManualControl('X-', handles);
    elseif  get(gcf,'CurrentCharacter') == 119      % 'w', Y+
        ManualControl('Y+', handles);
    elseif  get(gcf,'CurrentCharacter') == 115      % 's', Y-
        ManualControl('Y-', handles);
    elseif  get(gcf,'CurrentCharacter') == 113       % 'q', Z+
        ManualControl('Z+', handles);
    elseif  get(gcf,'CurrentCharacter') == 101       % 'e', Z-
        ManualControl('Z-', handles);
    elseif  get(gcf,'CurrentCharacter') == 92        % '\', vaccum
        pushbutton_Vaccum_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 13        %  /r, grasp
        pushbutton_Grasp_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 8         %  bs, release gripper
        pushbutton_GripperRelease_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 32        % space, reset
        pushbutton_Reset_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 102       % 'f', enlongation folding
        pushbutton_EnlongationFold_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 112       % 'p', enlongation inflating
        pushbutton_Enlongate_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 105       % 'i', folding open
        pushbutton_Fold_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 111       % 'o', s-collect
        pushbutton_Collect_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 108       % 'l', l-collect
        pushbutton_Location_Callback(hObject, 0, handles);
    elseif  get(gcf,'CurrentCharacter') == 43        % '+', step length + 2
        stepLength = stepLength + 2;
        set(handles.edit_ManualStep, 'String', num2str(stepLength))
    elseif  get(gcf,'CurrentCharacter') == 45        % '-', step length - 2
        stepLength = max(1, stepLength - 2);
        set(handles.edit_ManualStep, 'String', num2str(stepLength))
    end  
%     pause(0.1);
end


% --- Executes on button press in pushbutton_Reset.
function pushbutton_Reset_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_Reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Od;
global OdA;
global waterDepthPressure;
% if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
    if strcmp( get(handles.pushbutton_Vaccum, 'string'), 'Vaccum(\\):ON')
%         SendBytes( '`', handles );
        set(handles.pushbutton_Vaccum, 'String', 'Vaccum(\\):OFF');    
    end
    pressure = uint16(zeros(1,10));
    for i = 1 : 10
        pressure(i) = uint16 (pressure(i) + waterDepthPressure);
        
    end
    PressureSend(pressure); 
    
    if strcmp( get(handles.pushbutton_Grasp, 'string'), 'Grasp(Enter):ON')
        set(handles.pushbutton_Grasp, 'String', 'Grasp(Enter):OFF');
    end
% end

Od  = [0;1e-8;-325];
OdA = [0;1e-8;-325];
set(handles.text_ManualX, 'String', num2str(Od(1)));
set(handles.text_ManualY, 'String', int2str(Od(2)));
set(handles.text_ManualZ, 'String', num2str(Od(3)));



% --- Executes on button press in pushbutton_Grasp.
function pushbutton_Grasp_Callback(hObject, ~, handles)
% hObject    handle to pushbutton_Grasp (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global waterDepthPressure;
% if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
    if strcmp( get(handles.pushbutton_Vaccum, 'string'), 'Vaccum(\\):ON')
%         SendBytes( '`', handles );
        set(handles.pushbutton_Vaccum, 'String', 'Vaccum(\\):OFF');    
    end
    
    if      get(handles.radiobutton_GripperPressureHigh,'value')
        pressure = uint16(zeros(1,10));
        for i = 1 : 7
        pressure(i) = pressure(i) + uint16(waterDepthPressure);
        end
        pressure(8) =  pressure(8) + uint16(waterDepthPressure);
        pressure(9) = pressure(9) + uint16(waterDepthPressure);
        pressure(10) = uint16(60                                                                                                                                                                                                                                            ) + uint16(waterDepthPressure);
        PressureSend( pressure );
    
    elseif  get(handles.radiobutton_GripperPressureLow, 'value')
        pressure = uint16(zeros(1,10));
        for i = 1 : 7
        pressure(i) = pressure(i) + uint16(waterDepthPressure);
        end
        pressure(8) = uint16 ( 30 + waterDepthPressure );
        pressure(9) = pressure(9) + uint16(waterDepthPressure);
        pressure(10) = pressure(10) + uint16(waterDepthPressure);
        PressureSend( pressure );
    
    end

    if strcmp( get(handles.pushbutton_Grasp, 'string'), 'Grasp(Enter):OFF')
        set(handles.pushbutton_Grasp, 'String', 'Grasp(Enter):ON');
    end
% end

% --- Executes on button press in pushbutton_GripperRelease.
function pushbutton_GripperRelease_Callback(hObject, ~, handles)
% hObject    handle to pushbutton_GripperRelease (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% global waterDepthPressure;
global dotcp;
global open1;
global open2;
global close1;
global close2;

% if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
    if strcmp( get(handles.pushbutton_Vaccum, 'string'), 'Vaccum(\\):ON')
        fwrite(dotcp,open1(1,:),'char');
        fwrite(dotcp,open2(1,:),'char');
        %         SendBytes( '`', handles );
        set(handles.pushbutton_Vaccum, 'String', 'Vaccum(\\):OFF');    
    end

    if strcmp( get(handles.pushbutton_Grasp, 'string'), 'Grasp(Enter):ON')
        pressure = uint16(zeros(1,10));
        PressureSend( pressure );
        set(handles.pushbutton_Grasp, 'String', 'Grasp(Enter):OFF');
    end
% end


% --- Executes on button press in pushbutton_Vaccum.
function pushbutton_Vaccum_Callback(~, ~, handles)
% hObject    handle to pushbutton_Vaccum (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global dotcp;
global opendo6;
global opendo7;
global closedo7;
global closedo6;
if strcmp( get(handles.pushbutton_Vaccum, 'string'), 'Vaccum(\\):ON')
    set(handles.pushbutton_Vaccum, 'String', 'Vaccum(\\):OFF');
    fwrite(dotcp,closedo7(1,:),'char');
    pause(0.02);
    fwrite(dotcp,closedo6(1,:),'char');
    
elseif strcmp( get(handles.pushbutton_Vaccum, 'string'), 'Vaccum(\\):OFF')
    fwrite(dotcp,opendo7(1,:),'char');
    pause(0.02);
    fwrite(dotcp,opendo6(1,:),'char');
    set(handles.pushbutton_Vaccum, 'String', 'Vaccum(\\):ON');

end


% --- Executes on button press in radiobutton_GripperPressureHigh.
function radiobutton_GripperPressureHigh_Callback(~, ~, handles)
% hObject    handle to radiobutton_GripperPressureHigh (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_GripperPressureHigh
set(handles.radiobutton_GripperPressureHigh,'value',1);
set(handles.radiobutton_GripperPressureLow,'value',0);


% --- Executes on button press in radiobutton_GripperPressureLow.
function radiobutton_GripperPressureLow_Callback(~, ~, handles)
% hObject    handle to radiobutton_GripperPressureLow (see GCBO)
% ~  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_GripperPressureLow
set(handles.radiobutton_GripperPressureHigh,'value',0);
set(handles.radiobutton_GripperPressureLow,'value',1);



function edit_WaterDepth_Callback(~, ~, handles)
% hObject    handle to edit_WaterDepth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_WaterDepth as text
%        str2double(get(hObject,'String')) returns contents of edit_WaterDepth as a double
global waterDepthPressure;
% g = 9.886 m/s^2 (Beijing)
% sea water: rou = 1.025 g/cm^3
%     water: rou = 1.0 g/cm^3
% waterDepthPressure: kPa
waterDepthPressure = 9.886 * 1.025 * str2double(get(handles.edit_WaterDepth, 'String')) * 0.51;



function edit_ManualStep_Callback(~, ~, handles)
% hObject    handle to edit_ManualStep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ManualStep as text
%        str2double(get(hObject,'String')) returns contents of edit_ManualStep as a double
global stepLength;
% mm
stepLength = str2double(get(handles.edit_ManualStep, 'String'));


% --- Executes on button press in pushbutton_Collect.
function pushbutton_Collect_Callback(~, ~, handles)
% hObject    handle to pushbutton_Collect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global waterDepthPressure;
if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
%     SendBytes( 'A', handles );
    pressure = zeros(1,10);
    %pressure = [30; 0; 0; 0; 60; 50; 0];
    pressure(1) = 30 + waterDepthPressure;
    pressure(2) = 0 + waterDepthPressure;
    pressure(3) = 0 + waterDepthPressure;
    pressure(4) = 0 + waterDepthPressure;
    pressure(5) = 60 + waterDepthPressure;
    pressure(6) = 50 + waterDepthPressure;
    pressure(7) = 0 + waterDepthPressure;
    pressure(8) = 40 + waterDepthPressure;
    pressure(9) = 0 + waterDepthPressure;
    pressure(10) = 0 + waterDepthPressure;
    %pressure = [60; 0; 0; 0; 60; 50; 0];
    PressureSend( pressure ); 
end


% --- Executes on button press in pushbutton_Fold.
function pushbutton_Fold_Callback(~, ~, handles)
% hObject    handle to pushbutton_Fold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
    SendBytes( '&', handles );
    
    if strcmp( get(handles.pushbutton_Fold, 'string'), 'Open')
        set(handles.pushbutton_Fold, 'String', 'Close');
    elseif strcmp( get(handles.pushbutton_Fold, 'string'), 'Close')
        set(handles.pushbutton_Fold, 'String', 'Open');
    end
end

% --- Executes on button press in pushbutton_Location.
function pushbutton_Location_Callback(~, ~, handles)
% hObject    handle to pushbutton_Location (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global waterDepthPressure;
if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
%     SendBytes( 'A', handles );

    %pressure = [30; 0; 0; 0; 60; 50; 0];
   % pressure = [60; 0; 0; 0; 60; 50; 0];
    pressure(1) = 54;
    pressure(2) = 0;
    pressure(3) = 0;
    pressure(4) = 0;
    pressure(5) = 50;
    pressure(6) = 30;
    for i = 1 : 6
        PressureSend(int2str(pressure(i) + waterDepthPressure), i, handles ); 
%         PressureSend(int2str(pressure(i)), i, handles );
        pause(0.003);
    end
end

% --- Executes on button press in pushbutton_VisionAble.
function pushbutton_VisionAble_Callback(~, ~, handles)
% hObject    handle to pushbutton_VisionAble (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
    if strcmp( get(handles.pushbutton_VisionAble, 'string'), 'Able')
        set(handles.pushbutton_VisionAble, 'String', 'Disable');
    elseif strcmp( get(handles.pushbutton_VisionAble, 'string'), 'Disable')
        set(handles.pushbutton_VisionAble, 'String', 'Able');    
    end
% end


% --- Executes on button press in pushbutton_ExecuteVision.
function pushbutton_ExecuteVision_Callback(~, ~, handles)
% hObject    handle to pushbutton_ExecuteVision (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global OdA;
global d;
% if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop') &&...
%         strcmp( get(handles.pushbutton_VisionAble, 'string'), 'Disable')
if strcmp( get(handles.pushbutton_VisionAble, 'string'), 'Disable')
    VisionX = str2double(get(handles.text_VisionX, 'String'));
    VisionY = str2double(get(handles.text_VisionY, 'String'));
    VisionZ = str2double(get(handles.text_VisionZ, 'String'));
    
    VisionX = VisionX * 5;
    VisionY = VisionY * 5;
    VisionZ = VisionZ * 5;
    
%     fTrajectoryControl( OdA, OdA + [VisionX; VisionY; VisionZ], 'Free', 10, 's', d, handles );
    
    [ L1d(1), L1d(2), L1d(3), Ld3 ] = fInverseSimplified( OdA(1)+VisionX, OdA(2)+VisionY, OdA(3)+VisionZ, d );
    if ~fIsOverSpace( L1d(1), L1d(2), L1d(3), Ld3, handles )
        fDrivingSegments( L1d(1), L1d(2), L1d(3), Ld3, handles );
    else
        warndlg('The point is OUT of workspase!','Warning');
        return;
    end
end


% --- Executes on button press in pushbutton_EnlongationFold.
function pushbutton_EnlongationFold_Callback(~, ~, handles)
global waterDepthPressure;
% hObject    handle to pushbutton_EnlongationFold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
    SendBytes( '~', handles );
    %PressureSend(int2str(0), 7, handles); 
    
    if strcmp( get(handles.pushbutton_EnlongationFold, 'string'), 'Fold OFF (f)')
        set(handles.pushbutton_EnlongationFold, 'String', 'Fold ON (f)');
        %PressureSend(int2str(0), 7, handles);
    elseif strcmp( get(handles.pushbutton_EnlongationFold, 'string'), 'Fold ON (f)')
        set(handles.pushbutton_EnlongationFold, 'String', 'Fold OFF (f)');
        PressureSend(handles.edit_Ps7 + waterDepthPressure, 7, handles);
    end
end


%--- Executes on button press in pushbutton_Enlongate.
function pushbutton_Enlongate_Callback(~, ~, handles)
global waterDepthPressure;
 % hObject    handle to pushbutton_Enlongate (see GCBO)
 % eventdata  reserved - to be defined in a future version of MATLAB
 % handles    structure with handles and user data (see GUIDATA)
 if strcmp( get(handles.pushbutton_Start, 'string'), 'Stop')
     if strcmp( get(handles.pushbutton_EnlongationFold, 'string'), 'Fold ON (f)')
         set(handles.pushbutton_EnlongationFold, 'String', 'Fold OFF (f)');
         SendBytes( '~', handles );
     end
     
     if strcmp( get(handles.pushbutton_Enlongate, 'string'), 'Inflate OFF (p)')
          PressureSend(int2str(12 + waterDepthPressure), 7, handles); 
         set(handles.pushbutton_Enlongate, 'String', 'Inflate ON (p)');
     elseif strcmp( get(handles.pushbutton_Enlongate, 'string'), 'Inflate ON (p)')
         PressureSend(int2str(0 + waterDepthPressure), 7, handles); 
         set(handles.pushbutton_Enlongate, 'String', 'Inflate OFF (p)');
     end
 end



function edit_daip_Callback(hObject, eventdata, handles)
% hObject    handle to edit_daip (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_daip as text
%        str2double(get(hObject,'String')) returns contents of edit_daip as a double


% --- Executes during object creation, after setting all properties.
function edit_daip_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_daip (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% 
%CRC16У��λ����
function calculateCRC(command)
    global command_crc16Hi;
    global command_crc16Lo;
    global aucCRCHi;
    global aucCRCLo;
    uint16 iIndex;
    len = uint8( length(command));
    ucCRCHi = uint8(255); %0xFF
    ucCRCLo = uint8(255); %0xFF
    for i = 1 : len
        iIndex = bitxor( ucCRCLo,command(1,i) );
        ucCRCLo = bitxor( ucCRCHi,aucCRCHi(iIndex+1,1) );
        ucCRCHi = aucCRCLo(iIndex+1,1);
    end
    command_crc16Hi = ucCRCLo(:);
    command_crc16Lo = ucCRCHi(:);



function edit_doip_Callback(~, ~, ~)
% hObject    handle to edit_doip (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_doip as text
%        str2double(get(hObject,'String')) returns contents of edit_doip as a double


% --- Executes during object creation, after setting all properties.
function edit_doip_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_doip (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_daport_Callback(~, ~, ~)
% hObject    handle to edit_daport (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_daport as text
%        str2double(get(hObject,'String')) returns contents of edit_daport as a double


% --- Executes during object creation, after setting all properties.
function edit_daport_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_daport (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_doport_Callback(~, ~, handles)
% hObject    handle to edit_doport (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_doport as text
%        str2double(get(hObject,'String')) returns contents of edit_doport as a double


% --- Executes during object creation, after setting all properties.
function edit_doport_CreateFcn(hObject, ~, ~)
% hObject    handle to edit_doport (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_foldseg1.
function pushbutton_foldseg1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_foldseg1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global dotcp;
global opendo1;
global opendo7;
global closedo7;
global closedo1;
if strcmp( get(handles.pushbutton_foldseg1, 'string'), 'fold seg1')
    set(handles.pushbutton_foldseg1, 'String', 'ON');
    fwrite(dotcp,opendo7(1,:),'char');
    pause(0.02);
    fwrite(dotcp,opendo1(1,:),'char');
elseif strcmp( get(handles.pushbutton_foldseg1, 'string'), 'ON')
    set(handles.pushbutton_foldseg1, 'String', 'fold seg1');
    fwrite(dotcp,closedo7(1,:),'char');
    pause(0.02);
    fwrite(dotcp,closedo1(1,:),'char');
end


% --- Executes on button press in pushbutton_foldseg2.
function pushbutton_foldseg2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_foldseg2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global dotcp;
global opendo4;
global opendo7;
global closedo7;
global closedo4;
if strcmp( get(handles.pushbutton_foldseg2, 'string'), 'fold seg2')
    set(handles.pushbutton_foldseg2, 'String', 'ON');
    fwrite(dotcp,opendo7(1,:),'char');
    pause(0.02);
    fwrite(dotcp,opendo4(1,:),'char');
elseif strcmp( get(handles.pushbutton_foldseg2, 'string'), 'ON')
    set(handles.pushbutton_foldseg2, 'String', 'fold seg2');
    fwrite(dotcp,closedo7(1,:),'char');
    pause(0.02);
    fwrite(dotcp,closedo4(1,:),'char');
end


% --- Executes on button press in pushbutton_foldseg3.
function pushbutton_foldseg3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_foldseg3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global dotcp;
global opendo5;
global opendo7;
global closedo7;
global closedo5;
if strcmp( get(handles.pushbutton_foldseg3, 'string'), 'fold seg3')
    set(handles.pushbutton_foldseg3, 'String', 'ON');
    fwrite(dotcp,opendo7(1,:),'char');
    pause(0.02);
    fwrite(dotcp,opendo5(1,:),'char');
elseif strcmp( get(handles.pushbutton_foldseg3, 'string'), 'ON')
    set(handles.pushbutton_foldseg3, 'String', 'fold seg3');
    fwrite(dotcp,closedo7(1,:),'char');
    pause(0.02);
    fwrite(dotcp,closedo5(1,:),'char');
end


% --- Executes on button press in pushbutton35.
function pushbutton35_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton35 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
pressure1 = uint16([10,0 ,10,30, 0,30,30, 0, 0,20]);
pressure2 = uint16([0 ,20, 0,30, 0,30, 0, 0, 0,20]);
pressure3 = uint16([10,30,10,35, 5,35, 0, 0, 0,20]);
pressure4 = uint16([10,30,10,40,20,40, 0,25,25,20]);
pressure5 = uint16([10,30,10,30,10,30,10, 0, 0,30]);
pressure6 = uint16([20,0 ,20,40 ,0,40,10, 0, 0,30]);
pressure7 = uint16([0 ,0 , 0,30, 0,30,25, 0, 0,30]);

PressureSend(pressure1 * 2);
pause(3);
PressureSend(pressure7 * 2);
pause(3);
PressureSend(pressure2 * 2);
pause(3);
PressureSend(pressure3 * 2);
pause(3);
PressureSend(pressure4 * 2);
pause(8);
PressureSend(pressure5 * 2);
pause(3);
PressureSend(pressure6 * 2);
pause(3);


% --- Executes during object creation, after setting all properties.
function pushbutton_ON_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton_ON (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton36.
function pushbutton36_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

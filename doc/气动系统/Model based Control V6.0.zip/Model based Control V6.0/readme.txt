
             Underwater Soft Arm Control

             Zheyuan Gong
                                   2018.8.21
__________

Keyboard control:
	'd', 	X+
	'a', 	X-
	'w', 	Y+
	's', 	Y-
	'q', 	Z+
	'e', 	Z-
	'\', 	vaccum
	enter, 	grasp
	backspace,	 release gripper
	space, 	reset
	'f', 	enlongation folding
	'p', 	enlongation inflating
	'o', 	folding close
	'+', 	step length + 2
	'-', 	step length - 2
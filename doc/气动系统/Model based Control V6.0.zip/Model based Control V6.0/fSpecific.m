function [ theta, phi, r ] = fSpecific( L1, L2, L3, d )
% fSpecific transform for PCC model
%   Detailed explanation goes here

D = sqrt(L1^2 + L2^2 + L3^2 - L1*L2 - L1*L3 - L2*L3);
L = (L1+L2+L3)/3;
phi = atan((L2 + L3 - 2*L1) / (sqrt(3) * (L2 - L3)));
theta = 2*D /(3 * d);
r = L/theta;
if L3 > L2
    phi = phi + pi;
end

end


cam = ipcam('http://192.168.0.105:8080/video/mjpeg');
% Preview a stream of image frames.
preview(cam);
% Acquire and display a single image frame.
% img = snapshot(cam);
% imshow(img);
function [ L1, L2, L3, L4 ] = fInverseSimplified( x, y, z, d )
% Inverse kinematics for Simplified model
%   Detailed explanation goes here
syms phiF phiP c;

% initial length
initLength = 109;

% desired location
% Od = [x/2, y/2, (z+L3)/2];
Od = [x, y, z];

phi = - atan(Od(2)/Od(1));
    if Od(1) < 0
    phi = pi + phi;
    end
% while phi >= 1.5*pi
%    phi = phi - 2*pi; 
% end
% while phi < -0.5*pi
%    phi = phi + 2*pi; 
% end

if phi == pi/2
%     f(1) = (r - d * sin(phi)) * theta - initLength;
%     f(2) = - r*(1-cos(theta))*sin(phi) - y;
    phiF = phi;
    phiP = phi + pi/2;
    c = y/2;
elseif phi == -pi/2 || phi == 1.5*pi
%     f(1) = (r - d * cos(phi + pi/6)) * theta - initLength;
%     f(2) = - r*(1-cos(theta))*sin(phi) - y; 
    phiF = - phi + pi/3;
    phiP = phi + pi/2;
    c = y/2;
elseif phi >= pi/6 && phi < pi*5/6 && phi ~= pi/2
%     f(1) = (r - d * sin(phi)) * theta - initLength;
%     f(2) = r * cos(phi) * (1-cos(theta)) - x;
    phiF = phi;
    phiP = phi;
    c = x/2;
elseif phi >= pi*5/6 && phi < pi*3/2
%     f(1) = (r + d * cos(phi - pi/6)) * theta - initLength;
%     f(2) = r * cos(phi) * (1-cos(theta)) - x; 
    phiF = phi - 2*pi/3;
    phiP = phi;
    c = x/2;
elseif phi > -pi/2 && phi < pi/6
%     f(1) = (r - d * cos(phi + pi/6)) * theta - initLength;
%     f(2) = r * cos(phi) * (1-cos(theta)) - x; 
    phiF = - phi + pi/3;
    phiP = phi;
    c = x/2;

end

% theta = 2 * atan(sqrt((Od(1)^2+Od(2)^2)/Od(3)^2));
% r = - Od(3)/sin(theta);
t = fsolve(@fRoot2d,[150,0]);
r = t(1);
theta = t(2);

    function F = fRoot2d( t )
    % fsolve
    %   caculate r, theta
        F = [(t(1) - d * sin(phiF)) * t(2) - initLength; t(1) * cos(phiP) * (1-cos(t(2))) - c];
        
    end

% i = 1;
% while i <= length(r)    
%     if ~isempty(r)
%         if r(i) < 30
%             r(i) = [];
%             theta(i) = [];
%         end
%     end
%     i = i + 1;
%     if i > length(r)
%        i = 1;
%     end
% end

L1 = (r - d * sin(phi)) * theta;
L2 = (r + d * cos(phi - pi/6)) * theta;
L3 = (r - d * cos(phi + pi/6)) * theta;

L4 = - r*sin(theta) *2 - z;

% O1 = [r*(1-cos(theta))*cos(phi); - r*(1-cos(theta))*sin(phi); - r*sin(theta); 1];
% O2 = [2 * O1(1); 2 * O1(2); 2 * O1(3); 1];
% O3 = [O2(1); O2(2); O2(3) - L4; 1];

% [ O1, O2, O3 ] = fDrawCurvature( theta, phi, r, L4, '-b', 1 );

end

